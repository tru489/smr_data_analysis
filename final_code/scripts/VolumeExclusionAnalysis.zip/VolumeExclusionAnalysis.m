%
% TODO: add method SaveYourself, LoadYourself
%
classdef VolumeExclusionAnalysis < FigureManager

    % configuration
    properties
        SampleName = 'Foo'
        FileName = 'fooImages'
        AnalysisFolderPath = 'FooPath';
        TempFolderPath = 'FooPath';
        Hdf5FilePath = 'FooImages.hdf5';
        FullFrameHdf5FilePath = 'FooImages.hdf5';
        TempHdf5FilePath = 'FooImages.hdf5';
        MassDataFilePath = 'Foo_Mass.Data.csv';        
        MagnificationFL = 3.75; % This depends on the tube lens focal length; For 100mm tube lens: 7.5 * (100/200)
        MagnificationBR = 5.625; % 7.5 * (150/200)
        FrameRate = 1400;
        PixelSize = 3.45e-6; %m
        BRFrameSize = [78 720];
        FLFrameSize = [52 480];
        ChannelHeight = 24e-6; %m
        PixelVolume = 20.3136; % fl % (PixelSize/MagnificationFL)^2*ChannelHeight * 1e18;       
    end

    % Processing parameters
    properties
        Debug = true;
        SaveIntermediateData = false;
        SaveFinalObject = true;
        RemoveFrameOutliers = true;
        UseReferenceImage = true;
        BaselineSmoothingHalfWindowSize = 3;
        BaselineSmoothingAlgorighm = "movmean";
        NumberOfPositionCalibrationPoints = 21;
    end

    % QC parameters
    properties
        MinimumTrackLength = 12;
        MaximumXAlignmentShift = 3;
        MaximumYAlignmentShift = 3;
        UncalibratedNormalizedMeasurementRange = [0.75 1.25];
        IntensityRange = [1500 3500];
        CellSpeedRange = [0.01 0.05]; %m/s
        MinCellPosition = [10, 0];
        MaxCellPosition = [inf, inf];
        CellYPositionVariationLimits = [0.1, 2.5];
        CellTrajectoryRMSErrorLimits = [0.1, 2];
        CellImageWidthVariationLimits = [0.1, 5];
        CellImageHeightVariationLimits = [0.1, 5];
    end

    % Matching parameters
    properties
        Timebase = 1e-3;
        PeakTolerance = 11;
        GaussianWidthSamples = 15;
    end

    % computed results
    properties
        CellInfo;
        GoodCellInfo;
        TransitsWithErrors
    end

    % internal results
    properties
        metadataTable;
        rawMassDataTable;
        massData;
    end

    methods
        function main(this, debug)
            if nargin < 2, this.Debug = false;
            else this.Debug = debug; 
            end

            if strcmp(this.SampleName, 'Foo')
                % Prompt user to select the hdf5 file for analysis
                [imageFileName, imageFilePath] = uigetfile('*.hdf5', 'Select the HDF5 file for analysis', 'C:\Users\travera\Travera Dropbox\Selim Olcum\Travera Fluorescence Project');
                if isequal(imageFileName, 0)
                    disp('File selection was cancelled, analysis was not performed!');
                    return;
                else   
                    if imageFilePath(end) == filesep
                        imageFilePath = imageFilePath(1:end-1);
                    end
                    [~, this.SampleName] = fileparts(imageFilePath);
                    this.FileName = imageFileName(1:end-5);
                    this.AnalysisFolderPath = imageFilePath;
                    this.Hdf5FilePath = fullfile(this.AnalysisFolderPath, imageFileName);
                end
                 % Read the mass data csv
                [fileName, filePath] = uigetfile('*.csv', 'Select the mass csv file for matching', this.AnalysisFolderPath);
                this.MassDataFilePath = fullfile(filePath, fileName);
                if isequal(fileName, 0) 
                    disp('Mass data was not provided. No matching will be performed.');
                end
            end
    
            disp(append(this.SampleName, ' will be analyzed.'));
            disp(append(this.FileName, ' is the target image file.'));     
            fprintf('Automated analysis routine has been started for %s. \n', this.FileName);
            % Check if the HDF5 file is on the SSD, copy over to a temp folder if not
            if ~startsWith(this.Hdf5FilePath, 'E:')
                % Create temporary directory for the sample
                this.TempFolderPath = fullfile('E:/Temp Images', this.SampleName);
                if ~isfolder(this.TempFolderPath)
                    mkdir(this.TempFolderPath);
                end
        
                % Define the new temporary HDF5 file path
                [~, fileName, ext] = fileparts(this.Hdf5FilePath);
                this.TempHdf5FilePath = fullfile(this.TempFolderPath, append(fileName, ext));
        
                % Check if the temporary file already exists
                if exist(this.TempHdf5FilePath, 'file')
                    % Compare file sizes
                    fSource = dir(this.Hdf5FilePath);
                    fTemp   = dir(this.TempHdf5FilePath);
                    if fSource.bytes == fTemp.bytes
                        disp('Identical file found in the temporary location. Skipping copy.');
                    else
                        copyfile(this.Hdf5FilePath, this.TempHdf5FilePath);
                        disp(['HDF5 file copied to ', this.TempHdf5FilePath]);
                    end
                else
                    copyfile(this.Hdf5FilePath, this.TempHdf5FilePath);
                    disp(['HDF5 file copied to ', this.TempHdf5FilePath]);
                end

            else
                this.TempHdf5FilePath = this.Hdf5FilePath;
            end


            % Call methods in sequence
            this.LoadMetadata(true);
            this.EliminateBadTransits(true);
            this.MeasureVolume(true);
            pause(10)
            this.CleanTransitData(true);
            this.CalibratePosition(true);
            this.MatchMassAndVolume(true);
            % Save Results
            disp('Exporting scalar cell data to spreadsheet ...')
            this.ExportScalarData(fullfile(this.AnalysisFolderPath, append(this.SampleName,' ', this.FileName, ' CellInfo.csv')));
            % disp('Exporting hdf5 image paths to spreadsheet ...')
            % this.ExportHdf5Index(fullfile(filePath, [this.FileName, ' Hdf5PathIndex.csv']))
            if (this.SaveFinalObject)
                disp('Saving final analysis object ...')
                % Define the temp folder path and final save path
                tempSavePath = fullfile(this.TempFolderPath, append(this.SampleName,' ', this.FileName, ' Object.mat'));
                finalSavePath = fullfile(this.AnalysisFolderPath, append(this.SampleName,' ', this.FileName, ' Object.mat'));
                    % Save the object to the temporary folder
                save(tempSavePath, 'this', '-v7.3');
                disp(append('Object saved temporarily to: ', tempSavePath));           
                    % Copy the file to the final analysis folder
                copyfile(tempSavePath, finalSavePath);
                disp(append('Object copied to final location: ', finalSavePath));
            end
            % Display Results
            % TODO - save to pdf more efficiently
            this.GeneratePDFReport();
            % Check if the folder exists before attempting to delete
            if isfolder(fileparts(this.TempHdf5FilePath))
                % Delete the folder and its contents
                rmdir(fileparts(this.TempHdf5FilePath), 's'); % 's' flag ensures deletion of non-empty folders
                disp(append('Temporary folder deleted: ', fileparts(this.TempHdf5FilePath)));
            else
                disp(append('Temporary folder does not exist: ', fileparts(this.TempHdf5FilePath)));
            end
        end

        % Analysis functions
        function LoadMetadata(this, ForceLoad)
            if nargin < 2
                ForceLoad = false;
            end
        
            if ~isempty(this.CellInfo) && ~ForceLoad
                disp('MetaData already loaded. Function returns with no processing.')
                return
            end
        
            metadataFilename = [this.Hdf5FilePath(1:(end-5)), ' Parsed.mat'];
            % Load parsed metadata from file if it exists
            if exist(metadataFilename, 'file') && ~ForceLoad
                load(metadataFilename, 'cellInfo');
                this.CellInfo = cellInfo;
                disp('Previously processed MetaData loaded from file.')
                return
            end
        
            % Otherwise, read the full metadata structure, parse it, and save it
            disp('Reading metadata...')
            file_id = H5F.open(this.Hdf5FilePath, 'H5F_ACC_RDONLY', 'H5P_DEFAULT');
            % Initialize an empty cell array to store group names
            group_names = {};
            % Determine the list of group names available in the file
            i = 0;
            while true
                % Construct the group name in the format '/Group_i'
                group_path = sprintf('/Group_%d', i);
                % Check if the group exists
                % If the group exists, store the name in the cell array
                if H5L.exists(file_id, group_path, 'H5P_DEFAULT')
                    group_names{end+1} = group_path; %#ok<*SAGROW>
                else% Break the loop if the group does not exist
                    break;
                end
                % Increment the counter
                i = i + 1;
            end
            % Close the file
            H5F.close(file_id);
            %rawHdf5Info = h5info(this.Hdf5FilePath); % This reads the
            %whole file which can be very time consuming
            numberOfGroups = numel(group_names);
            parsedMetadata = [];
        
            convertTime = @(t) str2double(t(1:2)) * 3600 + str2double(t(3:4)) * 60 + str2double(t(5:end));
            hdf5FilePath = this.Hdf5FilePath;

            disp('Parsing metadata...')
            % Determine the number of workers
            pool = gcp('nocreate');  % Get the current parallel pool
            if isempty(pool)
                pool = parpool();
            end
            numWorkers = pool.NumWorkers;
            parfor ii = 1:numberOfGroups
                groupInfo = h5info(hdf5FilePath, group_names{ii});
                subGroups = groupInfo.Datasets;
                numberOfSubGroups = numel(subGroups);
                groupMetadata = [];
        
                if mod(numberOfSubGroups, 2) == 1
                    warning('Fluorescent and Brightfield images in the data are not exactly paired. Execution stopped.')
                    continue
                end
        
                for jj = 1:(numberOfSubGroups / 2)
                    subGroupInfoBF = subGroups(jj);
                    subGroupNameBF = subGroupInfoBF.Name;
                    subGroupPartsBF = strsplit(subGroupNameBF, '/');
                    subGroupNameOnlyBF = subGroupPartsBF{end};
                    subGroupPartsBF = split(subGroupNameOnlyBF, '_');
        
                    frame_type = subGroupPartsBF{1}; % This is either BF or FL, for brightfield or fluorescence
                    if frame_type ~= "BF" % Check if BF. Stop and display error if not
                        warning('HDF5 structure is not consistent with expectation. BF images are expected first.')
                        continue
                    end

                    subGroupInfoFL = subGroups(jj + numberOfSubGroups / 2);
                    subGroupNameFL = subGroupInfoFL.Name;
                    subGroupPartsFL = strsplit(subGroupNameFL, '/');
                    subGroupNameOnlyFL = subGroupPartsFL{end};
                    subGroupPartsFL = split(subGroupNameOnlyFL, '_');
                    if ~strcmp([subGroupPartsBF{2:4}],[subGroupPartsFL{2:4}])
                        warning('HDF5 structure is not consistent with expectation. Fluorescent and Brightfield images are not paired.')
                        continue
                    end

                    % Helper function to extract coordinates by label (e.g., "TL", "TR")
                    extract_coordinates = @(metadata_str, label) ...
                        str2double(split(regexprep(extractBetween(metadata_str, ...
                        [label, '('], ')'), '[^\d.,-]', ''), ','));
                    
                    % Extract the brightfield channel corner coordinates
                    bf_top_left = extract_coordinates(subGroupNameOnlyBF, 'TL')';
                    bf_top_right = extract_coordinates(subGroupNameOnlyBF, 'TR')';
                    bf_bottom_left = extract_coordinates(subGroupNameOnlyBF, 'BL')';
                    bf_bottom_right = extract_coordinates(subGroupNameOnlyBF, 'BR')';
                    corner_flag = extract_coordinates(subGroupNameOnlyBF, 'CF');
                    if isempty(corner_flag)
                        corner_flag = [];
                    end
                    % Extract the fluorescence channel corner coordinates
                    fl_top_left = extract_coordinates(subGroupNameOnlyFL, 'TL')';
                    fl_top_right = extract_coordinates(subGroupNameOnlyFL, 'TR')';
                    fl_bottom_left = extract_coordinates(subGroupNameOnlyFL, 'BL')';
                    fl_bottom_right = extract_coordinates(subGroupNameOnlyFL, 'BR')';

                    % Crop position data
                    imageSizeBF = subGroupInfoBF.Dataspace.Size;
                    imagePositionBF = [str2double(subGroupPartsBF{9}) str2double(subGroupPartsBF{10})]+1;% Account for python vs matlab indexing
                    centroidBF = imagePositionBF + imageSizeBF / 2;
                    imageSizeFL = subGroupInfoFL.Dataspace.Size;
                    imageSizeFL(2) = imageSizeFL(2) / 2; % Account for stacked reference image
                    imagePositionFL = [str2double(subGroupPartsFL{10}) str2double(subGroupPartsFL{11})]+1;% Account for python vs matlab indexing
                    centroidFL = imagePositionFL + imageSizeFL / 2;

                    % Full frame hdf5 paths
                    fullFramePath = [groupInfo.Name '/' subGroupPartsBF{2} '_' subGroupPartsBF{3} '_' subGroupPartsFL{7} '_' subGroupPartsBF{4}];
        
                    metadataEntry = struct(...
                                        'time', convertTime(subGroupPartsBF{2}), ...
                                        'packet', str2double(subGroupPartsBF{3}), ...
                                        'loopIndex', str2double(subGroupPartsBF{4}), ...
                                        'cellIdentifierInFrame', str2double(subGroupPartsBF{5}), ...
                                        'frame1', str2double(subGroupPartsBF{6}), ...
                                        'frame2', str2double(subGroupPartsFL{6}), ...
                                        'refIndex', str2double(subGroupPartsFL{7}), ...
                                        'class', str2double(subGroupPartsFL{8}), ...
                                        'confidence', str2double(subGroupPartsFL{9}), ...
                                        'intensityFL', str2double(subGroupPartsFL{12}), ...
                                        'pathFull', fullFramePath, ...
                                        'pathBF', [groupInfo.Name '/' subGroupInfoBF.Name], ...
                                        'imageSizeBF', imageSizeBF, ...
                                        'imagePositionBF', imagePositionBF, ...
                                        'centroidBF', centroidBF, ...
                                        'pathFL', [groupInfo.Name '/' subGroupInfoFL.Name], ...
                                        'imageSizeFL', imageSizeFL, ...
                                        'imagePositionFL', imagePositionFL, ...
                                        'centroidFL', centroidFL, ...
                                        'cornerFlag', corner_flag,...
                                        'BF_TL', bf_top_left, ...
                                        'BF_TR', bf_top_right, ...
                                        'BF_BL', bf_bottom_left, ...
                                        'BF_BR', bf_bottom_right, ...
                                        'FL_TL', fl_top_left, ...
                                        'FL_TR', fl_top_right, ...
                                        'FL_BL', fl_bottom_left, ...
                                        'FL_BR', fl_bottom_right);

        
                    groupMetadata = [groupMetadata; metadataEntry];
                end
                parsedMetadata = [parsedMetadata; groupMetadata];
            end
            metadataTable = struct2table(parsedMetadata);
            metadataTable.centroidBF1 = metadataTable.centroidBF(:, 1);
            metadataTable = sortrows(metadataTable, {'time', 'loopIndex', 'centroidBF1'});
            metadataTable.centroidBF1 = [];
      
            % Apply frame-level QC - TODO
            metadataTable(metadataTable.imagePositionBF(:,1) < this.MinCellPosition(1),:) = [];
            metadataTable(metadataTable.imagePositionBF(:,1) > this.MaxCellPosition(1),:) = [];
            metadataTable(metadataTable.imagePositionBF(:,2) < this.MinCellPosition(2),:) = [];
            metadataTable(metadataTable.imagePositionBF(:,2) > this.MaxCellPosition(2),:) = [];

            disp('Detecting cell transitions...')
            % Transition finding
            transitionIndexes = find(diff(metadataTable.loopIndex) > 5) + 1;
            transitionIndexesExtended = [1; transitionIndexes; height(metadataTable) + 1];
            numTransitions = length(transitionIndexesExtended) - 1;

            % Split the transition segments into chunks
            numberOfTransitions = length(transitionIndexesExtended) - 1;
            chunkSize = ceil(numberOfTransitions / numWorkers);
            chunkIndices = arrayfun(@(i) (i-1)*chunkSize+1 : min(i*chunkSize, numberOfTransitions), 1:numWorkers, 'UniformOutput', false);
            
            % Prepare a cell array to hold the updated groups
            updatedGroups = cell(numWorkers, 1);
            
            % Parallel processing using parfor
            parfor workerIdx = 1:numWorkers
                disp('Processing has started')
                % Initialize a cell array to store updated groups for this worker
                workerUpdatedGroups = cell(length(chunkIndices{workerIdx}), 1);
                
                for i = chunkIndices{workerIdx}
                    % Get the indices for the current transition segment
                    startIdx = transitionIndexesExtended(i);
                    endIdx = transitionIndexesExtended(i + 1) - 1;
            
                    % Extract the current group of data
                    currentGroup = metadataTable(startIdx:endIdx, :);
                    uniqueLoopIndexes = unique(currentGroup.loopIndex);
            
                    % Initialize tracking table for each group
                    trackingTable = containers.Map('KeyType', 'double', 'ValueType', 'any');
          
                    % Process each unique loopIndex in the current group
                    for loopIndex = uniqueLoopIndexes'
                        loopEntries = currentGroup(currentGroup.loopIndex == loopIndex, :);
                        % Initialize assignedIdentifiers for this loopIndex
                        assignedIdentifiers = [];
                        % Initialize temporary identifier for the loop
                        for k = 1:height(loopEntries)
                            x_position = loopEntries.imagePositionBF(k, 1);            
                            % Find the largest identifier that fits the criterion
                            assigned = false;
                            identifiers = cell2mat(keys(trackingTable));
                            % Iterate through identifiers to find the correct one
                            for idIdx = identifiers
                                if x_position < trackingTable(identifiers(idIdx))
                                    identifier = identifiers(idIdx);
                                    assigned = true;
                                    break;  % Exit the loop once an identifier is assigned
                                end
                            end
            
                            % If no existing identifier fits, assign a new one
                            if ~assigned
                                if isempty(trackingTable)
                                    identifier = 1;
                                else
                                    identifier = max(identifiers) + 1;
                                end
                            end
            
                            % Update the tracking table with the new identifier
                            trackingTable(identifier) = x_position;
            
                            % Store the identifier in the loop entries
                            loopEntries.cellIdentifierInFrame(k) = identifier;
                        end

                        %  % After processing all entries in this loopIndex, remove unassigned identifiers from trackingTable
                        % assignedIdentifiers = unique(assignedIdentifiers);
                        % identifiersInTrackingTable = cell2mat(keys(trackingTable));
                        % identifiersToRemove = setdiff(identifiersInTrackingTable, assignedIdentifiers);
                        % for idIdx = identifiersToRemove
                        %     identifier = identifiersToRemove(idIdx);
                        %     remove(trackingTable, identifier);
                        % end
                        % Update the original loop entries with the sorted and reassigned identifiers
                        currentGroup(currentGroup.loopIndex == loopIndex, :) = loopEntries;
                    end
            
                    % Store the processed current group in the worker's cell array
                    workerUpdatedGroups{i} = currentGroup;
                end
            
                % Store the updated groups for this worker
                updatedGroups{workerIdx} = vertcat(workerUpdatedGroups{:});
            end
            
            % After the parfor loop, concatenate the chunks to reassemble the metadataTable
            metadataTable = vertcat(updatedGroups{:});
            if ~all(diff(metadataTable.loopIndex) >= 0)
                disp('LoopIndex is not monotonically increasing. Analysis stopped.')
                % this.metadataTable = metadataTable;
                % return
            end
            % Parallel loop to process each TransitIndex
            % Preallocate a cell array to store cellInfo arrays from each parfor iteration
            cellInfoChunks = cell(numTransitions, 1);
            
            % Use parfor to loop over each unique TransitIndex
            parfor transit_index = 1:numTransitions
                % Get the current transit data
                startIdx = transitionIndexesExtended(transit_index);
                endIdx = transitionIndexesExtended(transit_index + 1) - 1;
            
                % Extract rows from metadataTable for the transit section
                currentGroup = metadataTable(startIdx:endIdx, :);
            
                % If no entries are found, store an empty array and continue
                if isempty(currentGroup)
                    cellInfoChunks{transit_index} = [];
                    continue;
                end
            
                % Get unique cell identifiers within the current group
                uniqueCellIdentifiers = unique(currentGroup.cellIdentifierInFrame);
            
                % Number of unique cells in this refIndex
                numCellsInGroup = numel(uniqueCellIdentifiers);
            
                % Preallocate a struct array for this group
                cellInfoList = repmat(struct('TransitIndex', [], 'TransitLengthFrames', [], ...
                                             'CellIdentifierInFrame', [], 'FrameTimes', [], ...
                                             'MedianFrameTimes', [], 'Volume', nan, 'CellSpeed', nan, ...
                                             'PacketNumbers', [], 'LoopIndexes', [], 'FrameNumbersBF', [], ...
                                             'FrameNumbersFL', [], 'RefIndexes', [], 'Intensities', [], ...
                                             'Classification', [], 'Confidence', [], 'Hdf5PathsFull', [], 'Hdf5PathsBF', [], ...
                                             'ImageSizeBF', [], 'ImagePositionBF', [], 'CentroidBF', [], ...
                                             'Hdf5PathsFL', [], 'ImageSizeFL', [], 'ImagePositionFL', [], ...
                                             'CentroidFL', [], 'BF_TL', [], 'BF_TR', [], 'BF_BL', [], 'BF_BR', [], ...
                                             'FL_TL', [], 'FL_TR', [], 'FL_BL', [], 'FL_BR', [], 'CornerFlag', [], ...
                                             'ErrorCode', "", 'DroppedFrames', []), numCellsInGroup, 1);

                % Process each unique cell within the current refIndex
                for idx = 1:numCellsInGroup
                    cell_index = uniqueCellIdentifiers(idx);
            
                    % Generate a unique TransitIndex
                    currentTransitIndex = transit_index * 100 + cell_index;
            
                    % Extract data for the current cell
                    currentCell = currentGroup(currentGroup.cellIdentifierInFrame == cell_index, :);
            
                    % Assign the values into cellInfoList(idx)
                    cellInfoList(idx).TransitIndex = currentTransitIndex;
                    cellInfoList(idx).TransitLengthFrames = height(currentCell);
                    cellInfoList(idx).CellIdentifierInFrame = cell_index;
                    cellInfoList(idx).FrameTimes = currentCell.time;
                    cellInfoList(idx).MedianFrameTimes = median(currentCell.time);
                    cellInfoList(idx).PacketNumbers = currentCell.packet;
                    cellInfoList(idx).LoopIndexes = currentCell.loopIndex;
                    cellInfoList(idx).FrameNumbersBF = currentCell.frame1;
                    cellInfoList(idx).FrameNumbersFL = currentCell.frame2;
                    cellInfoList(idx).RefIndexes = unique(currentCell.refIndex);
                    cellInfoList(idx).Intensities = mean(currentCell.intensityFL);
                    cellInfoList(idx).Classification = currentCell.class;
                    cellInfoList(idx).Confidence = currentCell.confidence;
                    cellInfoList(idx).ConsensusClass = mode(currentCell.class);
                    cellInfoList(idx).Hdf5PathsFull = currentCell.pathFull;
                    cellInfoList(idx).Hdf5PathsBF = currentCell.pathBF;
                    cellInfoList(idx).ImageSizeBF = currentCell.imageSizeBF;
                    cellInfoList(idx).ImagePositionBF = currentCell.imagePositionBF;
                    cellInfoList(idx).CentroidBF = currentCell.centroidBF;
                    cellInfoList(idx).Hdf5PathsFL = currentCell.pathFL;
                    cellInfoList(idx).ImageSizeFL = currentCell.imageSizeFL;
                    cellInfoList(idx).ImagePositionFL = currentCell.imagePositionFL;
                    cellInfoList(idx).CentroidFL = currentCell.centroidFL;
                    cellInfoList(idx).BF_TL = currentCell.BF_TL;
                    cellInfoList(idx).BF_TR = currentCell.BF_TR;
                    cellInfoList(idx).BF_BL = currentCell.BF_BL;
                    cellInfoList(idx).BF_BR = currentCell.BF_BR;
                    cellInfoList(idx).FL_TL = currentCell.FL_TL;
                    cellInfoList(idx).FL_TR = currentCell.FL_TR;
                    cellInfoList(idx).FL_BL = currentCell.FL_BL;
                    cellInfoList(idx).FL_BR =currentCell.FL_BR;
                    cellInfoList(idx).CornerFlag = currentCell.cornerFlag;
                    cellInfoList(idx).ErrorCode = "";
                end
            
                % Store the cellInfoList in the cell array
                cellInfoChunks{transit_index} = cellInfoList;
            end
            
            % After the parfor loop, concatenate the cellInfo structs from each chunk
            cellInfo = vertcat(cellInfoChunks{:});
            % Create a cell array of values
            transitionIndices = num2cell(1:numel(cellInfo));
            % Assign the values to the struct array fields
            [cellInfo.TransitIndex] = transitionIndices{:};
            [cellInfo.OutlierFrames] = deal([]);
            [cellInfo.AlignmentShifts] = deal([]);
            [cellInfo.UncalibratedMeasurements] = deal([]);
            [cellInfo.UncalibratedVolume] = deal(nan);
            [cellInfo.UncalibratedVolumeSE] = deal(nan);
            [cellInfo.UncalibratedNormalizedMeasurements] = deal([]);
            [cellInfo.UncalibratedNormalizedMeasurementsCV] = deal(nan);

            if this.SaveIntermediateData
                save( metadataFilename, 'cellInfo', '-v7.3' )
            end
            this.CellInfo = cellInfo;
        end

        function EliminateBadTransits(this, ForceComputation)
            if(nargin < 2)
                ForceComputation = false;
            end
          
            eliminatedFilename = [this.Hdf5FilePath(1:(end-5)), ' Eliminated.mat'];
            % load parsed metadata from file if it exists
            if(exist(eliminatedFilename, 'file')>0 && ~ForceComputation)
                load(eliminatedFilename, 'cellInfo');
                this.CellInfo = cellInfo;
                disp('Previously processed eliminated data frame loaded from file.')
                return
            end
            disp('Initial filtering data based on QC parameters...')

            % Apply QC Metrics for cell transits --
            % TODO
            % Initialize Error code
            [this.CellInfo.ErrorCode] = deal("");
            % Eliminate measurements where dye intensity is too low
            badOnes = ([this.CellInfo.Intensities] < this.IntensityRange(1) & [this.CellInfo.ErrorCode] == ""); 
            [this.CellInfo(badOnes).ErrorCode] = deal("Intensity out of range");
            % Eliminate transits that are too short or too long
            %badOnes = isoutlier([this.CellInfo.TransitLengthFrames], 'ThresholdFactor', 1) | ([this.CellInfo.TransitLengthFrames] < this.MinimumTrackLength);
            badOnes = ([this.CellInfo.TransitLengthFrames] < this.MinimumTrackLength & [this.CellInfo.ErrorCode] == "");
            [this.CellInfo(badOnes).ErrorCode] = deal("Frame count too short");

            if(this.Debug)
                this.PlotTransitData
            end                        
            badOnes = ([this.CellInfo.ErrorCode] ~= ""); 
            fprintf('%d of %d transits eliminated based on transit time.\n', sum(badOnes), numel(badOnes));
    
            cellInfo = this.CellInfo;
            if this.SaveIntermediateData
                save( eliminatedFilename, 'cellInfo', '-v7.3' );
            end
        end

        function MeasureVolume(this, ForceComputation)
            if nargin < 2
                ForceComputation = false;
            end
        
            volumeDataFilename = [this.Hdf5FilePath(1:(end-5)), ' Volume.mat'];
            if exist(volumeDataFilename, "file") > 0 && ~ForceComputation
                load(volumeDataFilename, 'cellInfo');
                this.CellInfo = cellInfo;
                disp('Previously processed uncalibrated volume data frame loaded from file.')
                return
            end
        
            disp('Cell volume calculation has been started...')
            % Extract data from struct for parallel processing
            cellInfo = this.CellInfo;
            useReferenceImage = this.UseReferenceImage;
            removeFrameOutliers = this.RemoveFrameOutliers;
            hdf5FilePath = this.TempHdf5FilePath;
       
            % Parallel processing
            numberOfCells = numel(cellInfo);
            % Parallel Processing settings
            pool = gcp('nocreate');  % Get the current parallel pool
            if isempty(pool)
                pool = parpool();
            end
            numWorkers = pool.NumWorkers;
        
            parfor ii = 1:numberOfCells
                if mod(ii, 1000) == 0
                    fprintf('Computing volume of row %d of %d\n', ii, numberOfCells)
                end
        
                if cellInfo(ii).ErrorCode ~= ""
                    continue
                end
        
                % Read in frames
                hdf5PathsBF = cellInfo(ii).Hdf5PathsBF;
                hdf5PathsFL = cellInfo(ii).Hdf5PathsFL;
                [~, FluorescentImageData, ReferenceImageData] = VolumeExclusionAnalysis.ReadImageDataFromHdf5FileStatic(hdf5FilePath, hdf5PathsBF, hdf5PathsFL);
                numberOfFrames = numel(FluorescentImageData);
        
                % Determine maximum dimensions
                frameSizes = cellfun(@size, FluorescentImageData, 'UniformOutput', false);
                frameSizes = vertcat(frameSizes{:});
                maxHeight = max(frameSizes(:, 1));
                maxWidth = max(frameSizes(:, 2));
        
                % Initialize normalizedData array
                normalizedData = nan(maxHeight, maxWidth, numberOfFrames);
        
                for jj = 1:numberOfFrames
                    if isempty(FluorescentImageData{jj})
                        fprintf('Image data missing in %s \n', hdf5PathsFL{jj})
                        continue
                    end

                    frameActual = double(FluorescentImageData{jj});
                    frameReference = double(ReferenceImageData{jj});
        
                    if useReferenceImage
                        % Normalize data using reference image as baseline
                        normalizedFrame = (frameReference - frameActual) ./ frameReference;
                    else
                        % Alternative normalization (if no reference image is used)
                        % Define baseline appropriately
                        baseline = frameReference; % Or some other baseline
                        normalizedFrame = (baseline - frameActual) ./ baseline;
                    end
        
                    % Calculate padding for centering
                    currentSize = size(normalizedFrame);
                    padTop = floor((maxHeight - currentSize(1)) / 2);
                    padBottom = ceil((maxHeight - currentSize(1)) / 2);
                    padLeft = floor((maxWidth - currentSize(2)) / 2);
                    padRight = ceil((maxWidth - currentSize(2)) / 2);
        
                    % Create padded frame
                    paddedFrame = padarray(normalizedFrame, [padTop, padLeft], nan, 'pre');
                    paddedFrame = padarray(paddedFrame, [padBottom, padRight], nan, 'post');
        
                    % Store in the 3D array
                    normalizedData(:, :, jj) = paddedFrame;
                end
                if all(isnan(normalizedData),'all')
                    fprintf('No image data in cell %d\n', ii)
                    cellInfo(ii).ErrorCode = "Fluorescence image data missing";
                    continue
                end
        
                % Initialize arrays to store mean values
                meanXValues = nan(maxHeight, numberOfFrames);
                meanYValues = nan(maxWidth, numberOfFrames);
        
                % Loop through each frame to calculate mean values
                for jj = 1:numberOfFrames
                    normalizedFrame = normalizedData(:, :, jj);
        
                    % Calculate mean values for X and Y axes
                    meanX = mean(normalizedFrame, 1, 'omitnan'); % Mean of all Y-axis pixels for each X-axis pixel
                    meanY = mean(normalizedFrame, 2, 'omitnan'); % Mean of all X-axis pixels for each Y-axis pixel
        
                    % Store mean values, aligning the center pixel
                    currentSize = size(normalizedFrame);
                    centerX = floor((maxWidth - currentSize(2)) / 2) + 1;
                    centerY = floor((maxHeight - currentSize(1)) / 2) + 1;
        
                    meanXValues(centerX:centerX+currentSize(2)-1, jj) = meanX;
                    meanYValues(centerY:centerY+currentSize(1)-1, jj) = meanY;
                end
        
                % Identify outlier frames
                cellInfo(ii).OutlierFrames = isoutlier(sqrt(mean(meanXValues, 1, 'omitnan').^2 + mean(meanYValues, 1, 'omitnan').^2));
        
                % Align Frames
                meanXValues(isnan(meanXValues)) = 0;
                meanYValues(isnan(meanYValues)) = 0;
                centerXTrend = mean(meanXValues, 2, 'omitnan');
                centerYTrend = mean(meanYValues, 2, 'omitnan');
        
                % Initialize array to store shifts
                cellInfo(ii).AlignmentShifts = zeros(2, numberOfFrames);
        
                % Calculate cross-correlation and determine shifts
                for jj = 1:numberOfFrames
                    % X-axis
                    [corrValues, lags] = xcorr(meanXValues(:, jj), centerXTrend, 'coeff');
                    [~, maxIndex] = max(corrValues);
                    cellInfo(ii).AlignmentShifts(1, jj) = lags(maxIndex);
        
                    % Y-axis
                    [corrValues, lags] = xcorr(meanYValues(:, jj), centerYTrend, 'coeff');
                    [~, maxIndex] = max(corrValues);
                    cellInfo(ii).AlignmentShifts(2, jj) = lags(maxIndex);
                end
        
                % Compute uncalibrated measurements
                cellInfo(ii).UncalibratedMeasurements = squeeze(sum(normalizedData, [1, 2], 'omitnan'));
                if removeFrameOutliers
                    uncalibratedMeasurements = cellInfo(ii).UncalibratedMeasurements(~cellInfo(ii).OutlierFrames);
                else
                    uncalibratedMeasurements = cellInfo(ii).UncalibratedMeasurements;
                end
        
                cellInfo(ii).UncalibratedVolume = mean(uncalibratedMeasurements, 'omitnan');
                if cellInfo(ii).UncalibratedVolume < 0
                    cellInfo(ii).ErrorCode = "Negative Volume";
                else
                    cellInfo(ii).UncalibratedVolumeSE = std(uncalibratedMeasurements) / sqrt(numel(uncalibratedMeasurements));
                    cellInfo(ii).UncalibratedNormalizedMeasurements = cellInfo(ii).UncalibratedMeasurements / mean(cellInfo(ii).UncalibratedMeasurements);
                    cellInfo(ii).UncalibratedNormalizedMeasurementsCV = std(cellInfo(ii).UncalibratedNormalizedMeasurements(~cellInfo(ii).OutlierFrames), 'omitnan');
                end
            end
            disp('Cell volume calculation is completed...')
        
            % Close parallel workers if needed
            pool = gcp('nocreate'); % Get the current parallel pool without creating a new one
            if ~isempty(pool)
                delete(pool); % Close the pool if it exists
            end
            this.CellInfo = cellInfo;
            if this.SaveIntermediateData
                save(volumeDataFilename, 'cellInfo', '-v7.3');
            end
        end

        function CleanTransitData(this, ForceClean)
            if nargin < 2
                ForceClean = false;
            end
        
            cleanedDataFilename = [this.Hdf5FilePath(1:(end-5)), ' Cleaned.mat'];
            % Load cleaned data if it exists and ForceClean is not set
            if exist(cleanedDataFilename, 'file') > 0 && ~ForceClean
                load(cleanedDataFilename, 'cellInfo');
                this.CellInfo = cellInfo;
                disp('Previously cleaned data loaded from file.')
                return
            end
        
            if isempty(this.CellInfo)
                fprintf("CellInfo is empty -- did you load/eliminate/measure?\n")
                return
            elseif ~isfield(this.CellInfo, 'UncalibratedVolume')
                fprintf("Uncalibrated Volume data not present -- did you run measureVolume?\n")
                return
            end
            
            disp('Identifying bad cell transits...')
            % Extract variables for parallel processing
            cellInfo = this.CellInfo;
            uncalibratedNormalizedMeasurementRange = this.UncalibratedNormalizedMeasurementRange;
            maximumXAlignmentShift = this.MaximumXAlignmentShift;
            maximumYAlignmentShift = this.MaximumYAlignmentShift;
            pixelSize = this.PixelSize;
            magnificationBR = this.MagnificationBR;
            frameRate = this.FrameRate;
            minimumTrackLength = this.MinimumTrackLength;
            cellSpeedRange = this.CellSpeedRange;
            intensityRange = this.IntensityRange;

            numberOfCells = numel(this.CellInfo);
            parfor ii = 1:numberOfCells
                if cellInfo(ii).ErrorCode ~= ""
                    continue
                end
        
                % Initialize OutlierFrames if not already present
                if isempty(cellInfo(ii).OutlierFrames)
                    cellInfo(ii).OutlierFrames = false(1,cellInfo(ii).TransitLengthFrames);
                end
        
                % Identify bad frames
                cellInfo(ii).OutlierFrames = cellInfo(ii).OutlierFrames | ...
                                                  (cellInfo(ii).UncalibratedMeasurements < 0)' | ...  % Check for negative UncalibratedMeasurement
                                                  (cellInfo(ii).UncalibratedNormalizedMeasurements < uncalibratedNormalizedMeasurementRange(1))' | ...  % Check for outlier UncalibratedNormalizedMeasurement
                                                  (cellInfo(ii).UncalibratedNormalizedMeasurements > uncalibratedNormalizedMeasurementRange(2))' | ...  % Check for outlier UncalibratedNormalizedMeasurement
                                                  isoutlier(cellInfo(ii).UncalibratedMeasurements') | ... % Check for outlier UncalibratedMeasurement
                                                  abs(cellInfo(ii).AlignmentShifts(1, :)) > maximumXAlignmentShift | ...
                                                  abs(cellInfo(ii).AlignmentShifts(2, :)) > maximumYAlignmentShift;
                if (sum(~cellInfo(ii).OutlierFrames)>1)
                    cellInfo(ii).CellSpeed = (max(cellInfo(ii).CentroidBF(~cellInfo(ii).OutlierFrames,1))-min(cellInfo(ii).CentroidBF(~cellInfo(ii).OutlierFrames,1)))*pixelSize/magnificationBR ...
                        / ((max(cellInfo(ii).FrameNumbersBF(~cellInfo(ii).OutlierFrames))-min(cellInfo(ii).FrameNumbersBF(~cellInfo(ii).OutlierFrames)))/frameRate);
                end

                % Identify bad transits
                if cellInfo(ii).TransitLengthFrames < minimumTrackLength
                    cellInfo(ii).ErrorCode = "Frame count too short";
                    continue;
                end

                if cellInfo(ii).CellSpeed < cellSpeedRange(1) || cellInfo(ii).CellSpeed > cellSpeedRange(2)
                    cellInfo(ii).ErrorCode = "CellSpeed out of range";
                    continue;
                end

                if cellInfo(ii).Intensities < intensityRange(1) || cellInfo(ii).Intensities > intensityRange(2)
                    cellInfo(ii).ErrorCode = "Intensity out of range";
                    continue;
                end

                if cellInfo(ii).UncalibratedVolume < 0
                    cellInfo(ii).ErrorCode = "Negative UncalibratedVolume";
                    continue;
                end

                % TODO Keep the following two conditions for selecting good
                % measurements for calibration. Then release the condition
                % to accept all the cells failing these two conditions after the calibration.
                if isoutlier(cellInfo(ii).UncalibratedNormalizedMeasurementsCV)
                    cellInfo(ii).ErrorCode = "Outlier Volume CV";
                    continue;
                end

                if isoutlier(cellInfo(ii).UncalibratedVolumeSE)
                    cellInfo(ii).ErrorCode = "Outlier Volume SE";
                    continue;
                end

            end
            this.CellInfo = cellInfo;

            % Save cleaned data
            if this.SaveIntermediateData
                save(cleanedDataFilename, 'cellInfo', '-v7.3');
            end
        end     

        function CalibratePosition( this , ForceCalibrate )
            if nargin < 2
                ForceCalibrate = false;
            end
        
            calibratedDataFilename = [ this.Hdf5FilePath(1:(end-5)), ' Calibrated.mat' ];
            % Load parsed metadata from file if it exists
            if exist(calibratedDataFilename, 'file')>0 && ~ForceCalibrate
                load(calibratedDataFilename, 'cellInfo');
                this.CellInfo = cellInfo;
                disp('Previously processed uncalibrated volume data frame loaded from file.')
                return
            end
        
            if isempty( this.CellInfo )
                fprintf( "CellInfo is empty -- did you load/eliminate/measure?\n")
                return
            elseif ~isfield( this.CellInfo, 'UncalibratedVolume' )
                fprintf( "Uncalibrated Volume data not present -- did you run measureVolume?\n")
                return
            end
        
            if size( this.CellInfo, 1 ) < 20
                fprintf( "CellInfo has less than 20 cells\n")
                return
            end
            
            disp('Applying position based calibration and normalization...')

            [ this.CellInfo.CalibratedVolume ] = deal( nan );
            [ this.CellInfo.CalibratedWeightedVolume ] = deal( nan );
            [ this.CellInfo.CalibratedStandardError ] = deal( nan );
            [ this.CellInfo.CalibratedCVPercent ] = deal( nan );
                    
            % Retrieve volume and position measurements for all cells and remove nans
            goodRows = strlength( vertcat( this.CellInfo.ErrorCode ) ) == 0;
            allCentroidsXY = vertcat( this.CellInfo(goodRows).CentroidFL );  
            allNormalizedVolumes = vertcat( this.CellInfo(goodRows).UncalibratedNormalizedMeasurements );
            allVolumes = vertcat(this.CellInfo(goodRows).UncalibratedVolume);
            allAlignmentShifts = horzcat(this.CellInfo(goodRows).AlignmentShifts)';

            % Identify and exclude bad frames and bad transits
            allFrameOutliers = horzcat( this.CellInfo(goodRows).OutlierFrames )';
            validFramesMask = ~allFrameOutliers & ~isnan(allNormalizedVolumes);
            
            allAlignmentShifts = allAlignmentShifts(validFramesMask,:);
            allCentroidsXY = allCentroidsXY(validFramesMask, :);
            allNormalizedVolumes = allNormalizedVolumes(validFramesMask);   
            allCentroidsX = allCentroidsXY(:,1);

            % Compute the calibration settings to minimize total squared error
            initialEqualizerSetting = ones( 1, this.NumberOfPositionCalibrationPoints );
            calibrationPositionX = linspace( min( allCentroidsX ), max( allCentroidsX ), numel( initialEqualizerSetting ));
            modelFunction = @( p, x ) interp1( calibrationPositionX, p, x, 'makima' ) .* allNormalizedVolumes;
            bestFit = nlinfit( allCentroidsX, ones( size( allCentroidsX ) ), modelFunction, initialEqualizerSetting );
            allCalibratedNormalizedVolumes = modelFunction( bestFit, allCentroidsX );
            normalizedCalibratedVolumeOutliers = isoutlier( allCalibratedNormalizedVolumes );
            positionCalibration = bestFit;
            calibrationFactorFunction = @(x) interp1( calibrationPositionX, positionCalibration, x, 'makima' );
        
            % Compute weighting factors (1 / variance)
            positionBin = discretize( allCentroidsX, calibrationPositionX );
            uncalibratedVariances = accumarray( positionBin, allNormalizedVolumes, [], @var );
            calibratedVariances = accumarray( positionBin, allCalibratedNormalizedVolumes, [], @var );
            weights = 1 ./ calibratedVariances;
            weights = weights / sum( weights );
            weightPositions = ( calibrationPositionX(1:end-1) + calibrationPositionX(2:end) ) / 2;
            weightingFactorFunction = @(x) interp1( weightPositions, weights, x, 'makima' );

            % Compute calibrated volume
            cellInfo = this.CellInfo;
            pixelVolume = this.PixelVolume;
            parfor ii = 1:numel( cellInfo )
                if( cellInfo(ii).ErrorCode ~= "" )
                    continue
                end
        
                % Compute calibration factors and weights
                centroidsX = vertcat( cellInfo(ii).CentroidFL(:,1) );
                uncalibratedMeasurements = vertcat( cellInfo(ii).UncalibratedMeasurements );
                validFrames = ~cellInfo(ii).OutlierFrames & ~isnan(uncalibratedMeasurements)';
                uncalibratedMeasurements = uncalibratedMeasurements(validFrames);
                centroidsX = centroidsX(validFrames);
        
                calibrationFactors = calibrationFactorFunction( centroidsX );
                weights = weightingFactorFunction( centroidsX );
                weights = weights / sum( weights );
        
                % Compute calibrated / unweighted volume and statistics
                cellInfo(ii).CalibratedMeasurements = uncalibratedMeasurements .* calibrationFactors;
                cellInfo(ii).CalibratedVolume = mean( cellInfo(ii).CalibratedMeasurements );
                cellInfo(ii).CalibratedStandardError = ...
                    std( cellInfo(ii).CalibratedMeasurements ) / sqrt( numel( cellInfo(ii).CalibratedMeasurements ) );
                cellInfo(ii).CalibratedCVPercent = cellInfo(ii).CalibratedStandardError / cellInfo(ii).CalibratedVolume * 100;
        
                % Compute calibrated / weighted volume and statistics
                cellInfo(ii).CalibratedWeightedVolume = sum( weights .* cellInfo(ii).CalibratedMeasurements );
                cellInfo(ii).CalibrationFunction = calibrationFactorFunction;
                cellInfo(ii).Volume = cellInfo(ii).CalibratedWeightedVolume * pixelVolume; % fl
            end
            this.CellInfo = cellInfo;
            if this.SaveIntermediateData
                save( calibratedDataFilename, 'cellInfo', '-v7.3' )
            end
        end

        function MatchMassAndVolume( this,  ForceMassRead)
             if(nargin < 2)
                ForceMassRead = false;
             end
            matchedDataFilename = [ this.Hdf5FilePath(1:(end-5)), ' Matched.mat' ];
            % load mass data if it is not already loaded
            if( isempty( this.rawMassDataTable ) || ForceMassRead )
                warning( 'off' )
                this.rawMassDataTable = readtable( this.MassDataFilePath );
                warning( 'on' )
                this.rawMassDataTable = sortrows( this.rawMassDataTable, 'time' );
            end
            disp('Matching volume measurements to mass measurements...')
            % create synthetic mass vs time signal (impulses)       
            allMassData = this.rawMassDataTable{:, 'mass'};
            allMassTimes = 60 * 60 * this.rawMassDataTable{:, 'time'};

            startTime = allMassTimes(1) - 0.1;
            endTime = allMassTimes(end) + 0.1;
            massTimeAxis = startTime:this.Timebase:endTime;
            massVersusTime = zeros( size( massTimeAxis ) );
            massWithoutNans = allMassData;
            massWithoutNans(isnan( massWithoutNans )) = 0;
            massTimeIndex = round( ( allMassTimes - startTime ) / this.Timebase );
            massVersusTime(massTimeIndex) = massWithoutNans;
            normalizedMassVersusTime = massVersusTime;
            normalizedMassVersusTime(normalizedMassVersusTime>0)=1;
            
            % blur mass impulses with Gaussian to create synthetic mass signal to use in correlation with synthetic volume vs time
            % signal
            timeAxisForGaussian = (-3*this.GaussianWidthSamples):(3*this.GaussianWidthSamples);
            gaussianKernel = exp(-( timeAxisForGaussian.^2 / this.GaussianWidthSamples^2 ) );
            massVersusTimeConvolvedWithGaussian = conv( normalizedMassVersusTime, gaussianKernel, 'same' );

            if( this.Debug )
                ah = this.GetAxesHandle( 'Mass/Volume Matching', 'Matched Mass and Volume' );
                cla( ah )
                plot( ah, massTimeAxis, massVersusTimeConvolvedWithGaussian .* massVersusTime, 'r' );
                hold( ah, 'on');

                lineColors = repmat( colororder( "glow12" ), [ 3 1 ] );
            end

            % this box signal vector is used to match volume samples to mass measurements after the offset has been
            % found
            massIndexVersusTime = zeros( size( massTimeAxis ) );
            maxIndex = length( massTimeAxis );
            for ii = 1:numel( allMassData )
                    indexRange = massTimeIndex(ii) + (-this.PeakTolerance:this.PeakTolerance);
                    indexRange(indexRange < 1) = [];
                    indexRange(indexRange > maxIndex ) = [];
                    massIndexVersusTime(indexRange) = ii;
            end
            
            % initialize computed fields in this.CellInfo
            [ this.CellInfo.Density ] = deal( nan );
            [ this.CellInfo.BuoyantDensity ] = deal( nan );
            [ this.CellInfo.VolumeTime ] = deal( nan );
            [ this.CellInfo.AcquisitionGroupNumber ] = deal( nan );
            [ this.CellInfo.Sample ] = deal( "" );
            [ this.CellInfo.SampleId ] = deal( "" );
            [ this.CellInfo.Condition ] = deal( "" );
            [ this.CellInfo.RunNumber ] = deal( nan );
            [ this.CellInfo.MassTime ] = deal( nan );
            [ this.CellInfo.MatchedMass ] = deal( nan );
            [ this.CellInfo.MassTableRow ] = deal( nan );

            % divide the data into segments for matching (flow rate should remain about constant over the segment)
            allVolumeTimes = arrayfun( @(x) x.FrameTimes(1), this.CellInfo );
            timeBreaks = find( diff( allVolumeTimes) > 10 );
            timeBreaks = timeBreaks(:);
            timeRanges = horzcat( [ 1; timeBreaks + 1 ], [ timeBreaks; numel(this.CellInfo) ] );

            % allocate space for results of each segment
            matchedCellInfo = cell( size( timeRanges, 1 ), 1 );

            % loop though the time ranges
            % match each segment to corresponding mass signal
            % compute density
            % back reference mass data
            for ii = 1:size( timeRanges, 1 )
                % create volume versus time signals (impulses)
                cellInfo = this.CellInfo(timeRanges(ii,1):timeRanges(ii,2));
                cellInfo = cellInfo( arrayfun( @(x) x.ErrorCode == "", cellInfo ) );
                [ cellInfo.ErrorCode ] = deal( "no mass match" );
                if (size(cellInfo,2) == 0)
                    continue;
                end

                % extract volume samples for this time interval
                volume = [ cellInfo.CalibratedWeightedVolume ];
                allVolumeTimes = arrayfun( @(x) x.FrameTimes(1), cellInfo );
                volumeTimeCell = num2cell( allVolumeTimes );
                [ cellInfo.VolumeTime ] = deal( volumeTimeCell{:} );
                
                if (size(allVolumeTimes,1) == 0)
                    continue;
                end

                % create a discrete-time axis for synthetic volume signal
                startTime = allVolumeTimes(1) - 1;
                endTime = allVolumeTimes(end) + 1;
                volumeTimeAxis = startTime:this.Timebase:endTime;

                % construct synthetic volume signal
                volumeVersusTime = zeros( size( volumeTimeAxis ) );
                volumeWithoutNans = volume;
                volumeWithoutNans(isnan( volumeWithoutNans )) = 0;
                if( sum( length(volumeWithoutNans) ) < 20 )
                    continue
                end

                % construct volume impulse signal and convolve with Gaussian
                VolumeTimeIndex = round(( allVolumeTimes - startTime )/ this.Timebase );
                volumeVersusTime(VolumeTimeIndex) = volumeWithoutNans;
                normalizedVolumeVersusTime = volumeVersusTime;
                normalizedVolumeVersusTime(normalizedVolumeVersusTime>0) = 1;
                volumeVersusTimeConvolvedWithGaussian = conv( normalizedVolumeVersusTime, gaussianKernel, 'same' );
    
                % use cross correlation to find time offset
                [ massXcorrVolume, lags ] = xcorr( massVersusTimeConvolvedWithGaussian, volumeVersusTimeConvolvedWithGaussian );
                [~, timeOffsetIndex] = max(massXcorrVolume);                
                timeOffsetIndex = lags( timeOffsetIndex );
                timeOffsetSeconds = timeOffsetIndex * this.Timebase + massTimeAxis(1) - volumeTimeAxis(1);
    
                if( this.Debug )
                    ah = this.GetAxesHandle( 'Mass/Volume Matching', 'Matched Mass and Volume' );
                    yyaxis( ah, 'right' );
                    plot( ah, volumeTimeAxis + timeOffsetSeconds, volumeVersusTimeConvolvedWithGaussian .* volumeVersusTime, color=lineColors(mod(ii,36),:) );

                    ah = this.GetAxesHandle( 'Mass/Volume Matching', 'Mass Volume Cross Correlation' );
                    plot( ah, lags, massXcorrVolume )
                    hold( ah, 'on' )
                    title( ah, 'Mass Volume Cross Correlation' )
                end            
    
                % clip out the relevant portion of the mass measurements  
                clippedMassVersusTime = normalizedMassVersusTime(max([(timeOffsetIndex+1),1]):min([(timeOffsetIndex+length(volumeTimeAxis)),maxIndex]));
                clippedBlurredMassIndex = massIndexVersusTime(max([(timeOffsetIndex+1),1]):min([(timeOffsetIndex+length(volumeTimeAxis)),maxIndex]));
                if timeOffsetIndex<1
                    clippedMassVersusTime = [zeros(1,abs(timeOffsetIndex)), clippedMassVersusTime];
                    clippedBlurredMassIndex = [zeros(1,abs(timeOffsetIndex)), clippedBlurredMassIndex];
                end

                % Ensure VolumeTimeIndex is within the bounds of volumeIndexVersusTime
                volumeIndexSize = numel(clippedMassVersusTime);
                VolumeTimeIndex = VolumeTimeIndex(VolumeTimeIndex <= volumeIndexSize);

                % create volume index versus time        
                volumeIndexVersusTime = zeros( size( clippedMassVersusTime ) );
                volumeIndexVersusTime(VolumeTimeIndex) = 1:numel(VolumeTimeIndex);
            
                % match mass and volume peaks by finding overlapping nonzero indexes
                matches = find( clippedBlurredMassIndex ~= 0 & volumeIndexVersusTime ~= 0 );
                matchedMassIndexes = clippedBlurredMassIndex(matches);
                matchedVolumeIndexes = volumeIndexVersusTime(matches);

                for jj = 1:length( matchedMassIndexes )
                    cellInfo(matchedVolumeIndexes(jj)).MatchedMass = allMassData(matchedMassIndexes(jj));
                    cellInfo(matchedVolumeIndexes(jj)).BuoyantDensity = cellInfo(matchedVolumeIndexes(jj)).MatchedMass / ( cellInfo(matchedVolumeIndexes(jj)).Volume );
                    cellInfo(matchedVolumeIndexes(jj)).Density = cellInfo(matchedVolumeIndexes(jj)).BuoyantDensity + 1;
                    cellInfo(matchedVolumeIndexes(jj)).Sample = this.rawMassDataTable{matchedMassIndexes(jj), 'sample'};
                    cellInfo(matchedVolumeIndexes(jj)).SampleId = this.rawMassDataTable{matchedMassIndexes(jj), 'sample_ID'};
                    cellInfo(matchedVolumeIndexes(jj)).Condition = this.rawMassDataTable{matchedMassIndexes(jj), 'condition'};
                    cellInfo(matchedVolumeIndexes(jj)).RunNumber = this.rawMassDataTable{matchedMassIndexes(jj), 'run_number'};
                    cellInfo(matchedVolumeIndexes(jj)).MassTime = this.rawMassDataTable{matchedMassIndexes(jj), 'time'};
                    cellInfo(matchedVolumeIndexes(jj)).MassTableRow = matchedMassIndexes(jj);
                    cellInfo(matchedVolumeIndexes(jj)).ErrorCode = "";
                end

                matchedCellInfo{ii} = cellInfo;
            end

            if( this.Debug )
                ah = this.GetAxesHandle( 'Mass/Volume Matching', 'Matched Mass and Volume' );
                hold( ah, 'off');
            end

            this.GoodCellInfo = vertcat( matchedCellInfo{:} );
            this.TransitsWithErrors = vertcat( ...
                this.CellInfo(arrayfun( @(x) x.ErrorCode ~= "", this.CellInfo ) ), ...
                this.GoodCellInfo(arrayfun( @(x) x.ErrorCode ~= "", this.GoodCellInfo ) ) ...
                );

            % Replace appropriate rows in this.CellInfo with rows from this.GoodCellInfo
            matchingCellIndices = ismember([this.CellInfo.TransitIndex], [this.GoodCellInfo.TransitIndex]);
            this.CellInfo(matchingCellIndices) = this.GoodCellInfo(:);
            this.GoodCellInfo = this.GoodCellInfo(arrayfun( @(x) x.ErrorCode == "", this.GoodCellInfo ));
            
            cellInfo = this.CellInfo;
            if this.SaveIntermediateData
                save( matchedDataFilename, 'cellInfo', '-v7.3' )
            end
        end

        % Utility functions
        function ExportScalarData(this, outputFilename)
            % Convert CellInfo to a table
            cellInfoTable = struct2table(this.CellInfo);
        
            % Function to check if a value is a valid scalar (numeric, string, char, or NaN)
            isValidScalar = @(x) (isnumeric(x) && isscalar(x) && ~isnan(x)) || ...
                                 (ischar(x) && isrow(x)) || ...
                                 (isstring(x) && isscalar(x)) || ...
                                 (iscell(x) && numel(x) == 1 && (isnumeric(x{1}) || ischar(x{1}) || isstring(x{1})));
        
            % Determine valid scalar columns
            scalarColumns = false(1, width(cellInfoTable));
        
            % Iterate over each column to check validity
            for colIdx = 1:width(cellInfoTable)
                columnData = cellInfoTable.(colIdx);
        
                if iscell(columnData)
                    % For cell arrays, apply isValidScalar to each element
                    scalarColumns(colIdx) = all(cellfun(isValidScalar, columnData));
                else
                    % For non-cell arrays, directly check the validity
                    scalarColumns(colIdx) = all(arrayfun(isValidScalar, num2cell(columnData)));
                end
            end
        
            % Keep only valid scalar columns
            scalarTable = cellInfoTable(:, scalarColumns);
        
            % Process 'Classification' field
            if ismember('Classification', cellInfoTable.Properties.VariableNames)
                classificationData = cellInfoTable.Classification;
                % Convert each row's numeric array into a string of integers
                classificationString = cellfun(@(x) strjoin(string(x), ''), classificationData, 'UniformOutput', false);
                scalarTable.ClassificationParsed = classificationString;
            end
        
            % Process 'Confidence' field
            if ismember('Confidence', cellInfoTable.Properties.VariableNames)
                confidenceData = cellInfoTable.Confidence;
                % Format each row's numeric array with two significant digits and concatenate with '_'
                confidenceStrings = cellfun(@(x) strjoin(arrayfun(@(y) sprintf('%.2f', y), x, 'UniformOutput', false), '_'), confidenceData, 'UniformOutput', false);
                scalarTable.ConfidenceParsed = confidenceStrings;
            end
        
            % Save the scalar table to a .csv file
            csvFilename = strrep(outputFilename, '.rda', '.csv');
            writetable(scalarTable, csvFilename);
        end


        function ExportHdf5Index(this, outputFilename)
            % Convert CellInfo to a table
            cellInfoTable = struct2table(this.CellInfo);
            
            % Columns to be used for indexing: TransitIndex, Hdf5PathsBF, Hdf5PathsFL
            transitIndexColumn = cellInfoTable.TransitIndex;
            hdf5PathsBFColumn = cellInfoTable.Hdf5PathsBF;
            hdf5PathsFLColumn = cellInfoTable.Hdf5PathsFL;
            
            % Initialize an empty table to store the flattened data
            flattenedData = table();
        
            % Iterate over each cell passage (TransitIndex)
            for rowIdx = 1:height(cellInfoTable)
                transitIndex = transitIndexColumn(rowIdx);
                bfPaths = hdf5PathsBFColumn{rowIdx};  % Get BF paths for this cell passage
                flPaths = hdf5PathsFLColumn{rowIdx};  % Get FL paths for this cell passage
                
                % Ensure both BF and FL paths have the same number of images
                numImages = min(length(bfPaths), length(flPaths));
                
                % Create temporary table for this cell passage, flattening BF and FL paths
                tempTable = table(repmat(transitIndex, numImages, 1), bfPaths(1:numImages), flPaths(1:numImages), ...
                                  'VariableNames', {'TransitIndex', 'Hdf5PathsBF', 'Hdf5PathsFL'});
                
                % Append the flattened data to the main table
                flattenedData = [flattenedData; tempTable];
            end
        
            % Save the flattened data to a CSV file
            csvFilename = strrep(outputFilename, '.rda', '_Hdf5PathIndex.csv');
            writetable(flattenedData, csvFilename);
        end

        function Baseline = ComputeBaseline( this, ImageData, boxLimitsX1Y1X2Y2 )
                numberOfFrames = size( ImageData, 3 );

                % mask out pixels with cells for baseline computation
                maskedImageData = ImageData;
                for jj = 1:numberOfFrames
                    if( ~isnan( boxLimitsX1Y1X2Y2(jj,1) ) )
                        maskedImageData(boxLimitsX1Y1X2Y2(jj,2):boxLimitsX1Y1X2Y2(jj,4),boxLimitsX1Y1X2Y2(jj,1):boxLimitsX1Y1X2Y2(jj,3), jj) = nan;
                    end
                end

                if( this.Debug )
                    maskedRawImageAxes = this.GetAxesHandle( 'Cell Diagnostic Plots', 'Masked Raw Images' );
                    imshow( this.TileImages( maskedImageData ), [] , 'Parent', maskedRawImageAxes )
                end

                % fill in masked areas
                Baseline = smoothdata( maskedImageData, 3, this.BaselineSmoothingAlgorighm, 2 * this.BaselineSmoothingHalfWindowSize + 1, "omitnan" );

                % show baseline
                if( this.Debug )
                    baselineImageAxes = this.GetAxesHandle( 'Cell Diagnostic Plots', 'Baseline Images' );
                    imshow( this.TileImages( Baseline ), [] , 'Parent', baselineImageAxes )
                end
        end
        
        function [BrightfieldImageData, FluorescentImageData, ReferenceImageData] = ReadImageDataFromHdf5File(this, RowNumber)
            % get the pathnames for the frames associated with this transit
            hdf5PathsBF = this.CellInfo(RowNumber).Hdf5PathsBF;
            hdf5PathsFL = this.CellInfo(RowNumber).Hdf5PathsFL;

            % initialize cell arrays to store frames
            BrightfieldImageData = cell(1, numel(hdf5PathsBF));
            FluorescentImageData = cell(1, numel(hdf5PathsFL));
            ReferenceImageData = cell(1, numel(hdf5PathsFL));
            
            % read the frames and store them in the cell array
            for jj = 1:numel(hdf5PathsBF)
                BrightfieldImageData{jj} = h5read(this.Hdf5FilePath, hdf5PathsBF{jj})';
                thisFrame = h5read(this.Hdf5FilePath, hdf5PathsFL{jj})';
                % Separate fluorescent image and reference image for each frame
                middleRow = size(thisFrame, 1) / 2;
                FluorescentImageData{jj} = thisFrame(1:middleRow, :, :);
                ReferenceImageData{jj} = thisFrame(middleRow+1:end, :, :);
            end
        end

        function [FullFrameBrightfieldImageData, FullFrameFluorescentImageData, FullFrameReferenceImageData] = ReadFullFrameDataFromHdf5File(this, RowNumber)
            % This function reads the full-frame Brightfield, Fluorescence, and Reference images from the HDF5 file specified by
            % this.FullFrameHdf5FilePath. 
        
            % Get the HDF5 paths for the full-frame images
            hdf5PathsFull = this.CellInfo(RowNumber).Hdf5PathsFull;

            % Initialize cell arrays to store the full-frame images
            FullFrameBrightfieldImageData = cell(1, numel(hdf5PathsFull));
            FullFrameFluorescentImageData = cell(1, numel(hdf5PathsFull));
            FullFrameReferenceImageData   = cell(1, numel(hdf5PathsFull));
        
            % Loop through each path in hdf5PathsFull
            for jj = 1:numel(hdf5PathsFull)
                currentPath = hdf5PathsFull{jj};
                try
                    info = h5info(this.FullFrameHdf5FilePath, currentPath);
                catch Error
                    disp(Error.message)
                    FullFrameBrightfieldImageData = [];
                    return
                end
                for iDataset = 1:numel(info.Datasets)
                    datasetName = info.Datasets(iDataset).Name;                      
                    % Build the full path to the dataset:
                    datasetFullPath = [currentPath '/' datasetName];
                    % -- Read the dataset
                    thisFrame = h5read(this.FullFrameHdf5FilePath, datasetFullPath)';
                    % -- Check if it's Brightfield or Fluorescence
                    if startsWith(datasetName, 'BR_')
                        % Store as brightfield image
                        FullFrameBrightfieldImageData{jj} = thisFrame;
                    elseif startsWith(datasetName, 'FL_')
                        % Separate the stacked fluorescent/reference image
                        middleRow = size(thisFrame, 1) / 2;
                        FullFrameFluorescentImageData{jj} = thisFrame(1:middleRow, :, :);
                        FullFrameReferenceImageData{jj}   = thisFrame(middleRow+1:end, :, :);
                    end
                end
            end
        end


        function SelectedCells = SelectCellsFromResults( this, MustContainSubstring, MustNotContainSubstring )
            if( nargin < 2 )
                MustContainSubstring = [];
            end
            
            if( nargin < 3 )
                MustNotContainSubstring = [];
            end
            
            if( ~isempty( MustContainSubstring ) )
                selection = arrayfun( @(x) contains( num2str(x.RunNumber), MustContainSubstring ), this.GoodCellInfo );
            else
                selection = true( size( this.GoodCellInfo ) )       ;
            end

            if( ~isempty( MustNotContainSubstring ) )
                selection = selction && ~arrayfun( @(x) contains( num2str(x.RunNumber), MustNotContainSubstring ), this.GoodCellInfo );
            end

            SelectedCells = this.GoodCellInfo( selection );
        end

    end

    % plotting methods
    methods
        function PlotTransitData(this)
            % Transit Length Histogram plot
            ah = this.GetAxesHandle('Detection Summary', 'Transit Length Histogram');
            bins = 0.5:1:50.5;
            xAxis = 1:50;
            countsGood = histcounts([this.CellInfo.TransitLengthFrames], bins);
            bar(ah, xAxis, countsGood', 'grouped')
            xline(ah, this.MinimumTrackLength, 'r', 'LineWidth', 1.5);
            xlabel(ah, 'Transit Length (frames)')
            ylabel(ah, 'Number of Transits')
            title(ah, 'Histogram of Transit Length')
            legend(ah, 'Good Transits', 'Minimum Track Length', 'Location', 'Best');
            
            % Rate of frame dropping in passages
            ah = this.GetAxesHandle('Detection Summary', 'Frame Dropping Pie Chart');
            % Calculate the dropped frames for each cell passage
            droppedFrames = arrayfun(@(x) sum(diff(x.LoopIndexes) - 1), this.CellInfo);
            % Get the unique counts of each number of dropped frames
            uniqueDrops = unique(droppedFrames);
            uniqueDrops(uniqueDrops == 0) = [];
            counts = fliplr(arrayfun(@(x) sum(droppedFrames == x), uniqueDrops));
            % Create pie chart
            bar(ah, uniqueDrops, counts/numel(this.CellInfo)*100);
            xlim([0 10])
            xlabel(ah, 'Number of Dropped Frames');
            ylabel(ah, 'Percentage of occurance');
            title(ah, 'Occurrences of Dropped Frames in Cell Passages');

            % Variation of Y-coord of centroid in cell passages
            ah = this.GetAxesHandle('Detection Summary', 'Variation in Y-position');
            stdYPosition = arrayfun(@(x) std(x.CentroidBF(:,2)), this.CellInfo);
            plot(ah, stdYPosition, '.');
            ylim(ah, [0 5]);
            yline(ah, this.CellYPositionVariationLimits, 'r', 'LineWidth', 1.5);
            xlabel(ah, 'Cell passage index');
            ylabel(ah, 'Y Position variance');
            title(ah, 'Variance in Y-position of the cells');
            
            % Error of time vs position trajectory
            ah = this.GetAxesHandle('Detection Summary', 'Error in time vs position trajectory');
            rmsErrors = arrayfun(@(x) ...
                                    sqrt(mean((x.CentroidBF(:,1) - ([x.LoopIndexes, ones(size(x.LoopIndexes))] * ...
                                    ([x.LoopIndexes, ones(size(x.LoopIndexes))] \ x.CentroidBF(:,1)))).^2)), ...
                                    this.CellInfo);
            plot(ah, rmsErrors, '.');
            ylim(ah, [0 10]);
            yline(ah, this.CellTrajectoryRMSErrorLimits, 'r', 'LineWidth', 1.5);
            xlabel(ah, 'Cell passage index');
            ylabel(ah, 'RMS Error of Cell trajectory');
            title(ah, 'RMS Error in Time vs Position trajectory of a cell');
        
            % Variation of image height
            ah = this.GetAxesHandle('Detection Summary', 'Variation in cell image height');
            stdImageHeight = arrayfun(@(x) std(x.ImageSizeBF(:,2)), this.CellInfo);
            plot(ah, stdImageHeight, '.');
            ylim(ah, [0 5]);
            yline(ah, this.CellImageHeightVariationLimits, 'r', 'LineWidth', 1.5);
            xlabel(ah, 'Cell passage index');
            ylabel(ah, 'Image height variance');
            title(ah, 'Variance in image height of the cells');
        
            % Variation of image width
            ah = this.GetAxesHandle('Detection Summary', 'Variation in cell image width');
            stdImageWidth = arrayfun(@(x) std(x.ImageSizeBF(:,1)), this.CellInfo);
            plot(ah, stdImageWidth, '.');
            ylim(ah, [0 5]);
            yline(ah, this.CellImageWidthVariationLimits, 'r', 'LineWidth', 1.5);
            xlabel(ah, 'Cell passage index');
            ylabel(ah, 'Image width variance');
            title(ah, 'Variance in image width of the cells');
            
            % MedianFrameTimes vs Intensities
            medianFrameTimes = [this.CellInfo.MedianFrameTimes];
            intensities = [this.CellInfo.Intensities];
            intensityErrorIndices = strcmp([this.CellInfo(:).ErrorCode], "Intensity out of range");
        
            ah = this.GetAxesHandle('Clean Transit Data', 'MedianFrameTimes vs Intensities', 'flow');
            hold(ah, 'on');
            plot(ah, medianFrameTimes(~intensityErrorIndices), intensities(~intensityErrorIndices), 'k.');
            plot(ah, medianFrameTimes(intensityErrorIndices), intensities(intensityErrorIndices), 'r.');
            ylim(ah, [0, this.IntensityRange(2)])
            hold(ah, 'off');
            xlabel(ah, 'Median Frame Times');
            ylabel(ah, 'Intensities');
            title(ah, 'Median Frame Times vs Intensities');
        
            % MedianFrameTimes vs CellSpeeds
            cellSpeeds = [this.CellInfo.CellSpeed];
            cellSpeedErrorIndices = strcmp([this.CellInfo(:).ErrorCode], "CellSpeed out of range");
                      
            ah = this.GetAxesHandle('Clean Transit Data', 'MedianFrameTimes vs CellSpeeds', 'flow');
            hold(ah, 'on');
            plot(ah, medianFrameTimes(~cellSpeedErrorIndices), cellSpeeds(~cellSpeedErrorIndices), 'k.');
            plot(ah, medianFrameTimes(cellSpeedErrorIndices), cellSpeeds(cellSpeedErrorIndices), 'r.');
            hold(ah, 'off');
            xlabel(ah, 'Median Frame Times');
            ylabel(ah, 'Cell Speeds');
            title(ah, 'Median Frame Times vs Cell Speeds');
        
            % MedianFrameTimes vs Outlier UncalibratedNormalizedMeasurementsCV
            uncalibratedNormalizedMeasurementsCV = [this.CellInfo.UncalibratedNormalizedMeasurementsCV];
            cvErrorIndices = strcmp([this.CellInfo(:).ErrorCode], "Outlier Volume CV");
                                  
            ah = this.GetAxesHandle('Clean Transit Data', 'MedianFrameTimes vs Outlier UncalibratedNormalizedMeasurementsCV', 'flow');
            hold(ah, 'on');
            plot(ah, medianFrameTimes(~cvErrorIndices), uncalibratedNormalizedMeasurementsCV(~cvErrorIndices), 'k.');
            plot(ah, medianFrameTimes(cvErrorIndices), uncalibratedNormalizedMeasurementsCV(cvErrorIndices), 'r.');
            hold(ah, 'off');
            ylim(ah, [0, 10])
            xlabel(ah, 'Median Frame Times');
            ylabel(ah, 'UncalibratedNormalizedMeasurementsCV');
            title(ah, 'Median Frame Times vs UncalibratedNormalizedMeasurementsCV');
        
            % MedianFrameTimes vs TransitLengthFrames
            transitLengthFrames = [this.CellInfo.TransitLengthFrames];
            lengthErrorIndices = strcmp([this.CellInfo(:).ErrorCode], "Frame count too short");
        
            ah = this.GetAxesHandle('Clean Transit Data', 'MedianFrameTimes vs TransitLengthFrames', 'flow');
            hold(ah, 'on');
            plot(ah, medianFrameTimes(~lengthErrorIndices), transitLengthFrames(~lengthErrorIndices), 'k.');
            plot(ah, medianFrameTimes(lengthErrorIndices), transitLengthFrames(lengthErrorIndices), 'r.');
            hold(ah, 'off');
            xlabel(ah, 'Median Frame Times');
            ylabel(ah, 'Transit Length Frames');
            title(ah, 'Median Frame Times vs Transit Length Frames');

        end

        function PlotCalibrationData(this)
            % TODO Simplify this section
            % Retrieve volume and position measurements for all cells and remove nans
            goodRows = strlength( vertcat( this.CellInfo.ErrorCode ) ) == 0;
            allCentroidsXY = vertcat( this.CellInfo(goodRows).CentroidFL );  
            allNormalizedVolumes = vertcat( this.CellInfo(goodRows).UncalibratedNormalizedMeasurements );
            allAlignmentShifts = horzcat(this.CellInfo(goodRows).AlignmentShifts)';

            % Identify and exclude bad frames and bad transits
            allFrameOutliers = horzcat( this.CellInfo(goodRows).OutlierFrames )';
            validFramesMask = ~allFrameOutliers & ~isnan(allNormalizedVolumes);
            
            allAlignmentShifts = allAlignmentShifts(validFramesMask,:);
            allCentroidsXY = allCentroidsXY(validFramesMask, :);
            allNormalizedVolumes = allNormalizedVolumes(validFramesMask);   
            allCentroidsX = allCentroidsXY(:,1);

            initialEqualizerSetting = ones( 1, this.NumberOfPositionCalibrationPoints );
            calibrationPositionX = linspace( min( allCentroidsX ), max( allCentroidsX ), numel( initialEqualizerSetting ));
            modelFunction = @( p, x ) interp1( calibrationPositionX, p, x, 'makima' ) .* allNormalizedVolumes;
            bestFit = nlinfit( allCentroidsX, ones( size( allCentroidsX ) ), modelFunction, initialEqualizerSetting );
            allCalibratedNormalizedVolumes = modelFunction( bestFit, allCentroidsX );
            normalizedCalibratedVolumeOutliers = isoutlier( allCalibratedNormalizedVolumes );
            positionCalibration = bestFit;
            calibrationFactorFunction = @(x) interp1( calibrationPositionX, positionCalibration, x, 'makima' );
            positionBin = discretize( allCentroidsX, calibrationPositionX );
            uncalibratedVariances = accumarray( positionBin, allNormalizedVolumes, [], @var );
            calibratedVariances = accumarray( positionBin, allCalibratedNormalizedVolumes, [], @var );
            weights = 1 ./ calibratedVariances;
            weights = weights / sum( weights );
            weightPositions = ( calibrationPositionX(1:end-1) + calibrationPositionX(2:end) ) / 2;
            weightingFactorFunction = @(x) interp1( weightPositions, weights, x, 'makima' );

            ah = this.GetAxesHandle( 'Position Calibration', 'Uncalibrated and Calibrated Normalized Volume vs Position');
            swarmchart( ah, positionBin, allNormalizedVolumes, 'r.' );
            hold( ah, 'on' )
            swarmchart( ah, positionBin + numel( calibrationPositionX ), allCalibratedNormalizedVolumes, 'b.' );
            plot( ah, [ 0, 2 *  numel( calibrationPositionX ) ], [ 1 1 ], 'k.' )
            axis( ah, 'off' )
            ah.XLim = [ 0, 2 *  numel( calibrationPositionX ) ];
            hold( ah, 'off' )
            title( ah, 'Uncalibrated and Calibrated Normalized Volume vs Position' );
    
            ah = this.GetAxesHandle( 'Position Calibration', 'Position Calibration');
            xAxis = linspace( calibrationPositionX(1), calibrationPositionX(end), 256 );
            plot( ah, xAxis, calibrationFactorFunction( xAxis ), 'LineWidth', 3 );
            hold( ah, 'on' )
            plot( ah, calibrationPositionX, positionCalibration, 'x', 'LineWidth', 3, 'MarkerSize', 9 );
            hold( ah, 'off' )
            title( ah, 'Position Calibration Factor' );
    
            ah = this.GetAxesHandle( 'Position Calibration', 'Measurement Weights');
            xAxis = linspace( calibrationPositionX(1), calibrationPositionX(end), 256 );
            plot( ah, xAxis, weightingFactorFunction( xAxis ), 'LineWidth', 3 );
            hold( ah, 'on' )
            plot( ah, weightPositions, weights, 'x', 'LineWidth', 3, 'MarkerSize', 9 );
            hold( ah, 'off' )
            title( ah, 'Measurement Weights' );
    
            ah = this.GetAxesHandle( 'Position Calibration', 'Calibrated Normalized Volume');
            plot( ah, allCentroidsX, allCalibratedNormalizedVolumes, '.' )
            hold( ah, 'on' )
            plot( ah, minmax( allCentroidsX(:)' ), [ 1 1 ] , 'b', 'LineWidth', 3 );
            hold( ah, 'off' )
            title( ah, [ 'Calibrated Normalized Volume vs Position (\sigma=' ...
            num2str(std( allCalibratedNormalizedVolumes(~normalizedCalibratedVolumeOutliers) ), 3 ) ')' ], 'x' )
    
            % Plot for X alignment shifts vs X position using swarmchart
            ah = this.GetAxesHandle('Position Calibration', 'X Alignment Shifts vs X Position');
            % Calculate mean alignment shifts for each bin
            meanXShift = accumarray(positionBin, allAlignmentShifts(:,1), [], @mean);                
            % Swarmchart for X alignment shifts
            swarmchart(ah, positionBin, allAlignmentShifts(:,1), 'filled', 'MarkerFaceColor', 'r');
            hold(ah, 'on');
            % Plot mean X alignment shift
            plot(ah, 1:numel(meanXShift), meanXShift, 'k-', 'LineWidth', 2);
            plot(ah, [0, numel(calibrationPositionX)], [0, 0], 'k--'); % Reference line at 0 shift
            xlabel(ah, 'X Position Bin');
            ylabel(ah, 'X Alignment Shift');
            title(ah, 'X Alignment Shifts vs X Position');
            ah.XLim = [0, numel(calibrationPositionX)];
            hold(ah, 'off');
            
            % Plot for Y alignment shifts vs X position using swarmchart
            ah = this.GetAxesHandle('Position Calibration', 'Y Alignment Shifts vs X Position');
            % Calculate mean alignment shifts for each bin
            meanYShift = accumarray(positionBin, allAlignmentShifts(:,2), [], @mean);
            
            % Swarmchart for Y alignment shifts
            swarmchart(ah, positionBin, allAlignmentShifts(:,2), 'filled', 'MarkerFaceColor', 'b');
            hold(ah, 'on');
            % Plot mean Y alignment shift
            plot(ah, 1:numel(meanYShift), meanYShift, 'k-', 'LineWidth', 2);
            plot(ah, [0, numel(calibrationPositionX)], [0, 0], 'k--'); % Reference line at 0 shift
            xlabel(ah, 'X Position Bin');
            ylabel(ah, 'Y Alignment Shift');
            title(ah, 'Y Alignment Shifts vs X Position');
            ah.XLim = [0, numel(calibrationPositionX)];
            hold(ah, 'off');

            ah = this.GetAxesHandle( 'Position Calibration', 'Uncalibrated and Calibrated Normalized Volume Distribution');
            [ counts, bins ] = histcounts( allNormalizedVolumes, linspace( -0.7, 2.3, 200 ) );
            plot( ah, (bins(2:end)+bins(1:end-1))/2, counts, 'r' );
            hold( ah, 'on' )
            [ counts, bins ] = histcounts( allCalibratedNormalizedVolumes, linspace( -0.7, 2.3, 200 ) );
            plot( ah, (bins(2:end)+bins(1:end-1))/2, counts, 'b' );
            hold( ah, 'off' )
            ah.XLim = [ 0.5 1.5 ];
            legend( ah, 'Uncalibrated', 'Calibrated')
            title( ah, 'Uncalibrated and Calibrated Normalized Volume Distribution' )
            
            % Histogram for X alignment shifts
            ah = this.GetAxesHandle('Position Calibration', 'X Alignment Shifts Histogram');
            histogram(ah, allAlignmentShifts(:, 1), 'FaceColor', 'r');
            xlabel(ah, 'X Alignment Shift');
            ylabel(ah, 'Frequency');
            title(ah, 'Histogram of X Alignment Shifts');

            % Histogram for Y alignment shifts
            ah = this.GetAxesHandle('Position Calibration', 'Y Alignment Shifts Histogram');
            histogram(ah, allAlignmentShifts(:, 2), 'FaceColor', 'b');
            xlabel(ah, 'Y Alignment Shift');
            ylabel(ah, 'Frequency');
            title(ah, 'Histogram of Y Alignment Shifts');
        end

        function ShowATransit(this, RowNumber, AxesHandle)
            if nargin < 3
                AxesHandle = [];
            end
        
            % Read image data from HDF5 file
            [BrightfieldImageData, FluorescentImageData, ReferenceImageData] = this.ReadImageDataFromHdf5File(RowNumber);
        
            % Get the cell information for positioning
            cellInfo = this.CellInfo(RowNumber);
        
            % Initialize full frame placeholders
            fullFrameBF = 128 * ones(this.BRFrameSize, 'uint8'); % Mid-gray for brightfield
            fullFrameFL = 128 * ones(this.FLFrameSize, 'uint16'); % Mid-gray for fluorescent
            fullFrameRef = 128 * ones(this.FLFrameSize, 'uint16'); % Mid-gray for reference
        
            numFrames = numel(BrightfieldImageData);
        
            % Loop over all frames and place the cropped images in the composite image
            for jj = 1:numFrames
                % Get size and position for brightfield image
                BFSize = cellInfo.ImageSizeBF(jj, :);
                if any(BFSize > fliplr(size(fullFrameBF)))
                    continue
                end
                BFPos = mod(cellInfo.ImagePositionBF(jj, :), fliplr(size(fullFrameBF)));
        
                % Get size and position for fluorescent image
                FLSize = cellInfo.ImageSizeFL(jj, :);
                if any(FLSize > fliplr(size(fullFrameFL)))
                    continue
                end
                FLPos = cellInfo.ImagePositionFL(jj, :);
        
                % Ensure the cropped image fits within the full frame
                % Check for Brightfield image boundaries
                if BFPos(1) < 1 || BFPos(2) < 1 || ...
                        BFPos(1) + BFSize(1) - 1 > size(fullFrameBF, 2) || ...
                        BFPos(2) + BFSize(2) - 1 > size(fullFrameBF, 1)
                    warning('Brightfield cropped image exceeds the boundaries of the full frame. Cropping to fit.');
                    
                    % Adjust Brightfield Position and Size
                    BFPos(1) = max(1, BFPos(1));
                    BFPos(2) = max(1, BFPos(2));
                    
                    BFSize(1) = min(BFSize(1), size(fullFrameBF, 2) - BFPos(1) + 1);
                    BFSize(2) = min(BFSize(2), size(fullFrameBF, 1) - BFPos(2) + 1);
                end
            
                % Check for Fluorescent image boundaries
                if FLPos(1) < 1 || FLPos(2) < 1 || ...
                        FLPos(1) + FLSize(1) - 1 > size(fullFrameFL, 2) || ...
                        FLPos(2) + FLSize(2) - 1 > size(fullFrameFL, 1)
                    warning('Fluorescent cropped image exceeds the boundaries of the full frame. Cropping to fit.');
                    
                    % Adjust Fluorescent Position and Size
                    FLPos(1) = max(1, FLPos(1));
                    FLPos(2) = max(1, FLPos(2));
                    
                    FLSize(1) = min(FLSize(1), size(fullFrameFL, 2) - FLPos(1) + 1);
                    FLSize(2) = min(FLSize(2), size(fullFrameFL, 1) - FLPos(2) + 1);
                end
        
                % Place the cropped images onto the full frames
                fullFrameBF(BFPos(2):BFPos(2) + BFSize(2) - 1, ...
                    BFPos(1):BFPos(1) + BFSize(1) - 1) = BrightfieldImageData{jj}(1:BFSize(2), 1:BFSize(1));
                fullFrameFL(FLPos(2):FLPos(2) + FLSize(2) - 1, ...
                    FLPos(1):FLPos(1) + FLSize(1) - 1) = FluorescentImageData{jj}(1:FLSize(2), 1:FLSize(1));
                fullFrameRef(FLPos(2):FLPos(2) + FLSize(2) - 1, ...
                    FLPos(1):FLPos(1) + FLSize(1) - 1) = ReferenceImageData{jj}(1:FLSize(2), 1:FLSize(1));
            end
        
            % Scale the brightfield image to match the 12-bit range
            fullFrameBF = uint16(fullFrameBF) * 16;
        
            % Resize images to match the largest image size
            maxWidth = max([size(fullFrameBF, 2), size(fullFrameFL, 2), size(fullFrameRef, 2)]);
            maxHeight = max([size(fullFrameBF, 1), size(fullFrameFL, 1), size(fullFrameRef, 1)]);
        
            resizedBF = imresize(fullFrameBF, [maxHeight, maxWidth]);
            resizedFL = imresize(fullFrameFL, [maxHeight, maxWidth]);
            resizedRef = imresize(fullFrameRef, [maxHeight, maxWidth]);
        
            % Create a buffer zone between images
            bufferZone = 2; % Buffer zone in pixels
            totalHeight = 3 * maxHeight + 2 * bufferZone;
            stackedImage = 128 * ones(totalHeight, maxWidth, 'uint16');
        
            % Stack images vertically with buffer zones
            stackedImage(1:maxHeight, :) = resizedBF;
            stackedImage(maxHeight + bufferZone + 1:2 * maxHeight + bufferZone, :) = resizedFL;
            stackedImage(2 * maxHeight + 2 * bufferZone + 1:end, :) = resizedRef;
        
            % Display the stacked image
            if isempty(AxesHandle)
                figure;
                imshow(stackedImage, []);
                title(['Transit Number ' num2str(RowNumber) ' - ' num2str(numFrames) ' frames']);
            else
                imshow(stackedImage, [], 'Parent', AxesHandle);
                title(AxesHandle, ['Transit Number ' num2str(RowNumber) ' - ' num2str(numFrames) ' frames']);
            end
        end

        function ShowAFullFrameTransit(this, RowNumber)        
            % 1. Read the full-frame data
            [FullFrameBF, FullFrameFL, FullFrameRef] = this.ReadFullFrameDataFromHdf5File(RowNumber);
            numFrames = numel(FullFrameBF);
            if numFrames == 0
                warning('No full-frame data found for RowNumber %d.', RowNumber);
                return;
            end
        
            cellInfo = this.CellInfo(RowNumber);
            % 2. Create BF mosaic
            bfHeights = cellfun(@(im) size(im,1), FullFrameBF);
            bfWidths  = cellfun(@(im) size(im,2), FullFrameBF);
            totalBFHeight = sum(bfHeights);
            maxBFWidth    = max(bfWidths);
            mosaicBF = 128 * ones(totalBFHeight, maxBFWidth, 'uint16');  % gray fill
            bfStartRows = zeros(numFrames,1);        
            offsetY = 0;
            for iFrame = 1:numFrames
                bfFrame = FullFrameBF{iFrame};
                if isempty(bfFrame), continue; end
                [h, w] = size(bfFrame);
                mosaicBF(offsetY + 1 : offsetY + h, 1 : w) = bfFrame;
                bfStartRows(iFrame) = offsetY + 1;
                offsetY = offsetY + h;
            end
        
            % 3. Create FL mosaic
            flHeights = cellfun(@(im) size(im,1), FullFrameFL);
            flWidths  = cellfun(@(im) size(im,2), FullFrameFL);
            totalFLHeight = sum(flHeights);
            maxFLWidth    = max(flWidths);
            mosaicFL = 128 * ones(totalFLHeight, maxFLWidth, 'uint16');
            flStartRows = zeros(numFrames,1);
            offsetY = 0;
            for iFrame = 1:numFrames
                flFrame = FullFrameFL{iFrame};
                if isempty(flFrame), continue; end
                [h, w] = size(flFrame);
                mosaicFL(offsetY + 1 : offsetY + h, 1 : w) = flFrame;
                flStartRows(iFrame) = offsetY + 1;
                offsetY = offsetY + h;
            end
        
            % 4. Create (FL - Ref) mosaic (double)
            flMinusRefHeights = zeros(numFrames,1);
            flMinusRefWidths  = zeros(numFrames,1);
            tempFlMinusRef    = cell(numFrames,1);
            for iFrame = 1:numFrames
                flFrame  = FullFrameFL{iFrame};
                refFrame = FullFrameRef{iFrame};
                if isempty(flFrame) || isempty(refFrame), continue; end
                flDouble  = double(flFrame);
                refDouble = double(refFrame);
                diffFrame = flDouble - refDouble;  % FL minus Reference
                tempFlMinusRef{iFrame}   = diffFrame;
                flMinusRefHeights(iFrame) = size(diffFrame,1);
                flMinusRefWidths(iFrame)  = size(diffFrame,2);
            end
            totalDiffHeight = sum(flMinusRefHeights);
            maxDiffWidth    = max(flMinusRefWidths);
            mosaicFlMinusRef = zeros(totalDiffHeight, maxDiffWidth, 'double');
            diffStartRows    = zeros(numFrames,1);
            offsetY = 0;
            for iFrame = 1:numFrames
                diffFrame = tempFlMinusRef{iFrame};
                if isempty(diffFrame), continue; end
                [h, w] = size(diffFrame);
                mosaicFlMinusRef(offsetY + 1 : offsetY + h, 1 : w) = diffFrame;
                diffStartRows(iFrame) = offsetY + 1;
                offsetY = offsetY + h;
            end
        
            % 5. Display in 3 subplots (1x3)
            figure('Name', sprintf('BF | FL-Ref | FL (Cell %d)', RowNumber), ...
                   'Units', 'normalized', 'Position', [0.1 0.1 0.9 0.9]);
            %%% Column 1: BF mosaic
            subplot(1, 3, 1);
            imshow(mosaicBF, []);
            axis image;
            title('Brightfield Mosaic');
            hold on;
        
            % BF corners/boxes
            bf_tl = cellInfo.BF_TL;  bf_tr = cellInfo.BF_TR;
            bf_bl = cellInfo.BF_BL;  bf_br = cellInfo.BF_BR;
            bf_positions = cellInfo.ImagePositionBF;
            bf_sizes     = cellInfo.ImageSizeBF;
        
            for iFrame = 1:numFrames
                yOffset = bfStartRows(iFrame) - 1;
                % BF corners
                if iFrame <= size(bf_tl,1)
                    plot(bf_tl(iFrame,1), bf_tl(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(bf_tr(iFrame,1), bf_tr(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(bf_bl(iFrame,1), bf_bl(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(bf_br(iFrame,1), bf_br(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                end
        
                % BF bounding box
                if iFrame <= size(bf_positions,1) && iFrame <= size(bf_sizes,1)
                    xPos = bf_positions(iFrame,1);
                    yPos = bf_positions(iFrame,2);
                    wBox = bf_sizes(iFrame,1);
                    hBox = bf_sizes(iFrame,2);
                    rectangle('Position', [xPos, (yPos + yOffset), wBox, hBox], ...
                              'EdgeColor','r','LineWidth',0.5);
                end
            end
            hold off;
        
            %%% Column 2: FL - Ref mosaic
            subplot(1, 3, 2);
            imshow(mosaicFlMinusRef, []);  % double, auto-scaled
            axis image;
            title('FL - Ref Mosaic');
            hold on;
        
            % Overlays the FL corners/boxes on the difference mosaic
            fl_tl = cellInfo.FL_TL;  fl_tr = cellInfo.FL_TR;
            fl_bl = cellInfo.FL_BL;  fl_br = cellInfo.FL_BR;
            fl_positions = cellInfo.ImagePositionFL;
            fl_sizes     = cellInfo.ImageSizeFL;
        
            for iFrame = 1:numFrames
                yOffset = diffStartRows(iFrame) - 1;  % vertical offset in the difference mosaic
        
                % FL corners on the difference
                if iFrame <= size(fl_tl,1)
                    plot(fl_tl(iFrame,1), fl_tl(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(fl_tr(iFrame,1), fl_tr(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(fl_bl(iFrame,1), fl_bl(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(fl_br(iFrame,1), fl_br(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                end
        
                % FL bounding box
                if iFrame <= size(fl_positions,1) && iFrame <= size(fl_sizes,1)
                    xPos = fl_positions(iFrame, 1);
                    yPos = fl_positions(iFrame, 2);
                    wBox = fl_sizes(iFrame, 1);
                    hBox = fl_sizes(iFrame, 2);
                    rectangle('Position', [xPos, yPos + yOffset, wBox, hBox], ...
                              'EdgeColor','r','LineWidth',0.5);
                end
            end
            hold off;
        
            %%% Column 3: FL mosaic
            subplot(1, 3, 3);
            imshow(mosaicFL, []);
            axis image;
            title('Fluorescent Mosaic');
            hold on;
        
            % Overlays the same FL corners/boxes, but now using flStartRows offsets
            for iFrame = 1:numFrames
                yOffset = flStartRows(iFrame) - 1;  % vertical offset in the FL mosaic
        
                % FL corners
                if iFrame <= size(fl_tl,1)
                    plot(fl_tl(iFrame,1), fl_tl(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(fl_tr(iFrame,1), fl_tr(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(fl_bl(iFrame,1), fl_bl(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                    plot(fl_br(iFrame,1), fl_br(iFrame,2) + yOffset, '.r', 'MarkerSize', 6);
                end
        
                % FL bounding box
                if iFrame <= size(fl_positions,1) && iFrame <= size(fl_sizes,1)
                    xPos = fl_positions(iFrame, 1);
                    yPos = fl_positions(iFrame, 2);
                    wBox = fl_sizes(iFrame, 1);
                    hBox = fl_sizes(iFrame, 2);
                    rectangle('Position', [xPos, yPos + yOffset, wBox, hBox], ...
                              'EdgeColor','r','LineWidth',0.5);
                end
            end
            hold off;
            % After all subplots are done, compute corner flags:
            cornerFlags = cellInfo.CornerFlag;    % Suppose this is a 1-by-numFrames array
            numCornerFlags = sum(cornerFlags == 1);
            totalFrames = numel(cornerFlags);
        
            % Create the text you want, e.g. (15,15) indicating 15 out of 15 were 1
            cornerFlagText = sprintf('%d/%d', numCornerFlags, totalFrames);
        
            % Then add a supertitle with sgtitle
            sgtitle(sprintf('Full-Frame Analysis for Cell %d - %s corner Flags are T. Error: %s', RowNumber, cornerFlagText, cellInfo.ErrorCode));
        end


        function ShowBadTransits( this )
            for ii = 1:size( this.CellInfo,2 )
                if( this.CellInfo.ErrorCode(ii) ~= "" )
                    this.ShowATransit(ii)
                    drawnow
                end
            end
        end

        function ShowABunchOfTransits( this, RowRange )
            ah = this.GetAxesHandle( 'Bunch of Transits', [ 'Rows ' num2strRowRange(1) '-' RowRange(2) ] );
            for ii = RowRange(1)
            end
        end

        function ShowVolumeAnalysis(this, cellIndex)
            % Check if the cellIndex is valid
            if cellIndex < 1 || cellIndex > numel(this.CellInfo)
                error('Invalid cellIndex. It must be between 1 and %d.', numel(this.CellInfo));
            end
        
            cellInfo = this.CellInfo(cellIndex);
        
            if cellInfo.ErrorCode ~= ""
                warning('Cell passage %d has an error: %s', cellIndex, cellInfo.ErrorCode);
                %return;
            end
        
            % Read in frames
            hdf5PathsBF = cellInfo.Hdf5PathsBF;
            hdf5PathsFL = cellInfo.Hdf5PathsFL;
            [~, FluorescentImageData, ReferenceImageData] = VolumeExclusionAnalysis.ReadImageDataFromHdf5FileStatic(this.Hdf5FilePath, hdf5PathsBF, hdf5PathsFL);
            numberOfFrames = numel(FluorescentImageData);
        
            % Determine maximum dimensions
            frameSizes = cellfun(@size, FluorescentImageData, 'UniformOutput', false);
            frameSizes = vertcat(frameSizes{:});
            maxHeight = max(frameSizes(:, 1));
            maxWidth = max(frameSizes(:, 2));
        
            % Initialize normalizedData array
            normalizedData = nan(maxHeight, maxWidth, numberOfFrames);
        
            for jj = 1:numberOfFrames
                frameActual = double(FluorescentImageData{jj});
                frameReference = double(ReferenceImageData{jj});
        
                if this.UseReferenceImage
                    % Normalize data using reference image as baseline
                    normalizedFrame = (frameReference - frameActual) ./ frameReference;
                else
                    % Alternative normalization (if no reference image is used)
                    % Define baseline appropriately
                    baseline = frameReference; % Or some other baseline
                    normalizedFrame = (baseline - frameActual) ./ baseline;
                end
        
                % Calculate padding for centering
                currentSize = size(normalizedFrame);
                padTop = floor((maxHeight - currentSize(1)) / 2);
                padBottom = ceil((maxHeight - currentSize(1)) / 2);
                padLeft = floor((maxWidth - currentSize(2)) / 2);
                padRight = ceil((maxWidth - currentSize(2)) / 2);
        
                % Create padded frame
                paddedFrame = padarray(normalizedFrame, [padTop, padLeft], nan, 'pre');
                paddedFrame = padarray(paddedFrame, [padBottom, padRight], nan, 'post');
        
                % Store in the 3D array
                normalizedData(:, :, jj) = paddedFrame;
            end
        
            % Use stored alignment shifts
            alignmentShifts = cellInfo.AlignmentShifts;
            maxShiftXPos = max(alignmentShifts(1, :));
            maxShiftXNeg = -min(alignmentShifts(1, :));
            maxShiftYPos = max(alignmentShifts(2, :));
            maxShiftYNeg = -min(alignmentShifts(2, :));
        
            % Align mean values (meanXValues and meanYValues need to be recomputed)
            meanXValues = nan(maxWidth, numberOfFrames);
            meanYValues = nan(maxHeight, numberOfFrames);
        
            for jj = 1:numberOfFrames
                normalizedFrame = normalizedData(:, :, jj);
        
                % Calculate mean values for X and Y axes
                meanX = mean(normalizedFrame, 1, 'omitnan'); % Mean of all Y-axis pixels for each X-axis pixel
                meanY = mean(normalizedFrame, 2, 'omitnan'); % Mean of all X-axis pixels for each Y-axis pixel
        
                meanXValues(:, jj) = meanX';
                meanYValues(:, jj) = meanY;
            end
        
            % Align frames using alignment shifts
            alignedMeanXValues = nan(size(meanXValues, 1) + maxShiftXPos + maxShiftXNeg, numberOfFrames);
            alignedMeanYValues = nan(size(meanYValues, 1) + maxShiftYPos + maxShiftYNeg, numberOfFrames);
        
            for jj = 1:numberOfFrames
                if cellInfo.OutlierFrames(jj)
                    continue
                end
                shiftX = alignmentShifts(1, jj);
                shiftY = alignmentShifts(2, jj);
        
                % Calculate new indices
                newIdxX = (1 + maxShiftXPos - shiftX):(size(meanXValues, 1) + maxShiftXPos - shiftX);
                newIdxY = (1 + maxShiftYPos - shiftY):(size(meanYValues, 1) + maxShiftYPos - shiftY);
        
                % Populate aligned matrices
                alignedMeanXValues(newIdxX, jj) = meanXValues(:, jj);
                alignedMeanYValues(newIdxY, jj) = meanYValues(:, jj);
            end
        
            % Compute aligned normalized data
            normalizedAlignedData = nan(maxHeight + maxShiftYPos + maxShiftYNeg, maxWidth + maxShiftXPos + maxShiftXNeg, numberOfFrames);
            for jj = 1:numberOfFrames
                shiftX = alignmentShifts(1, jj);
                shiftY = alignmentShifts(2, jj);
        
                % Calculate new indices
                newIdxX = (1 + maxShiftXPos - shiftX):(size(normalizedData, 2) + maxShiftXPos - shiftX);
                newIdxY = (1 + maxShiftYPos - shiftY):(size(normalizedData, 1) + maxShiftYPos - shiftY);
        
                % Populate aligned matrices
                normalizedAlignedData(newIdxY, newIdxX, jj) = normalizedData(:, :, jj);
            end
        
            % Compute mean normalized aligned cell image
            meanNormalizedAlignedCellImage = mean(normalizedAlignedData(:, :, ~cellInfo.OutlierFrames), 3, 'omitnan');
        
            % Plotting
            figureManager = FigureManager();
        
            % Show transit plot
            showATransitAxesHandle = figureManager.GetAxesHandle('Debug Plots', sprintf('Transit Plot %d', cellIndex), 'flow');
            VolumeExclusionAnalysis.showATransitStatic(this.Hdf5FilePath, cellInfo, this.BRFrameSize, this.FLFrameSize, cellInfo.Hdf5PathsBF, cellInfo.Hdf5PathsFL, showATransitAxesHandle);

            % Clipped, normalized images
            clippedNormalizedImagesAxesHandle = figureManager.GetAxesHandle('Debug Plots', sprintf('Clipped Normalized Images %d', cellIndex), 'flow');
            imshow(FigureManager.TileImages(normalizedAlignedData), [], 'Parent', clippedNormalizedImagesAxesHandle);
            title(clippedNormalizedImagesAxesHandle, 'Clipped Normalized Cell Images');
        
            % Mean normalized cell image
            meanNormalizedCellImageAxesHandle = figureManager.GetAxesHandle('Debug Plots', sprintf('Mean Normalized Image %d', cellIndex), 'flow');
            imshow(meanNormalizedAlignedCellImage, [], 'Parent', meanNormalizedCellImageAxesHandle);
            title(meanNormalizedCellImageAxesHandle, 'Mean Normalized Aligned Cell Image');
        
            % Plot aligned mean values for X-axis
            alignedMeanXAxesHandle = figureManager.GetAxesHandle('Debug Plots', sprintf('Aligned Mean Values for X-axis %d', cellIndex), 'flow');
            plot(alignedMeanXAxesHandle, alignedMeanXValues, 'LineWidth', 2);
            title(alignedMeanXAxesHandle, 'Aligned Mean Values for X-axis');
            xlabel(alignedMeanXAxesHandle, 'X-axis Pixel');
            ylabel(alignedMeanXAxesHandle, 'Mean Value');
            grid(alignedMeanXAxesHandle, 'on');
        
            % Plot aligned mean values for Y-axis
            alignedMeanYAxesHandle = figureManager.GetAxesHandle('Debug Plots', sprintf('Aligned Mean Values for Y-axis %d', cellIndex), 'flow');
            plot(alignedMeanYAxesHandle, alignedMeanYValues, 'LineWidth', 2);
            title(alignedMeanYAxesHandle, 'Aligned Mean Values for Y-axis');
            xlabel(alignedMeanYAxesHandle, 'Y-axis Pixel');
            ylabel(alignedMeanYAxesHandle, 'Mean Value');
            grid(alignedMeanYAxesHandle, 'on');
        
            % Uncalibrated volume plot
            uncalibratedVolumeAxesHandle = figureManager.GetAxesHandle('Debug Plots', sprintf('Uncalibrated Volume %d', cellIndex), 'flow');
            plot(uncalibratedVolumeAxesHandle, cellInfo.CentroidFL(:, 1), cellInfo.UncalibratedMeasurements, 'x');
            uncalibratedVolumeAxesHandle.YLim = sort([0, max(cellInfo.UncalibratedMeasurements)]);
            title(uncalibratedVolumeAxesHandle, 'Uncalibrated Volume Measurements');
        
            % Set the title for the entire figure
            figureManager.SetFigureTitle('Debug Plots', sprintf('Debug Plots for Cell Transit %d - %s', cellIndex, cellInfo.ErrorCode));
        
            drawnow;
        end

        function GeneratePDFReport(this, outputFolder)
            % Generate and export all relevant plots, each as a separate PDF.
            
            % Close any open figures to start fresh
            close all;
        
            % Call the plotting functions to generate the figures
            this.PlotSummary();
            this.SummarizeErrors();
            this.PlotTransitData();
            this.PlotCalibrationData();
        
            % Display random volume analyses for 15 cells with no errors
            for cellTransitIndex = randsample(find([this.CellInfo.ErrorCode] == ""), 15)
                try
                    this.ShowAFullFrameTransit(cellTransitIndex);
                catch Error
                    disp('Full frame transit failed to display.');
                end
                try
                    this.ShowVolumeAnalysis(cellTransitIndex);  
                catch Error
                    disp('Volume analysis failed to display.');
                end
            end

            % Display random volume analyses for 15 cells with  errors
            for cellTransitIndex = randsample(find([this.CellInfo.ErrorCode] ~= ""), 15)
                try
                    this.ShowAFullFrameTransit(cellTransitIndex);
                catch Error
                    disp('Full frame transit failed to display.');
                end
                try
                    this.ShowVolumeAnalysis(cellTransitIndex);  
                catch Error
                    disp('Volume analysis failed to display.');
                end
            end

        
            % Define the output folder path
            if nargin < 2
                outputFolder = fullfile(this.TempFolderPath, [this.SampleName, '_Report_Files']);
            end
        
            % Create the folder if it does not exist
            if ~exist(outputFolder, 'dir')
                mkdir(outputFolder);
            end
        
            % Get a list of open figures
            figHandles = findall(groot, 'Type', 'figure');
            figHandles = flipud(figHandles);  % Ensure correct order
        
            % Save each figure as a separate PDF
            pdfFiles = cell(numel(figHandles), 1);  % Store PDF filenames
            for i = 1:numel(figHandles)
                % Create a unique filename for each figure
                pdfFilename = fullfile(outputFolder, sprintf('Figure_%02d.pdf', i));
                pdfFiles{i} = pdfFilename;  % Store the filename
        
                % Export the figure as a PDF
                exportgraphics(figHandles(i), pdfFilename, 'ContentType', 'image', 'Resolution', 150);
        
                % Close the figure to save memory
                close(figHandles(i));
            end
        
            % Close any remaining open figures
            close all;
        
            % Merge all PDFs into a single PDF
            mergedPdfPath = fullfile(this.AnalysisFolderPath, append(this.SampleName, ' ', this.FileName, ' TransitDataReport.pdf'));
            success = VolumeExclusionAnalysis.mergePDFs(pdfFiles, mergedPdfPath);
        
            % Display success message
            if success
                disp(['PDF report generated and saved to: ', mergedPdfPath]);
                pause(5)
                % Delete the temporary folder and its contents
                [rmdirStatus, rmdirError] = rmdir(outputFolder, 's');
                if (rmdirStatus)
                    disp('Temp pdf folder is removed.');
                else
                    disp(rmdirError)
                end
            else
                disp('Failed to merge PDFs.');
            end
        end

        function SummarizeErrors( this )
            ah = this.GetAxesHandle( 'Error Breakdown', 'Error Messages');
            allErrorMessages = unique( string( { this.TransitsWithErrors.ErrorCode } ) );
            occurrences = arrayfun( @(x) sum( string( { this.TransitsWithErrors.ErrorCode } ) == x ), allErrorMessages );
            allErrorMessages = [ "no error", allErrorMessages];
            occurrences = [ numel( this.GoodCellInfo ), occurrences ];
            errorTable = table( allErrorMessages', occurrences', 'VariableNames', { 'Error Message', 'Count' } );
            errorTable = sortrows( errorTable, 'Count', 'descend' );
            bar( ah, errorTable{:,"Count"} );
            ah.XTickLabel = errorTable{:,"Error Message"};
            title( ah, 'Error Message Breakdown', FontSize=18 )
            ah.XAxis.FontSize = 18;
        end

        function PlotSummary( this, Queries )
            if( nargin < 2 )
                Queries = unique( string( { this.GoodCellInfo.RunNumber } ) );
            end

            this.CloseFigure();

            for ii = 1:numel( Queries )
                if( isempty( Queries ))
                    mcs = [];
                else
                    mcs = Queries{ii};
                end

                allCellInfo = this.SelectCellsFromResults( mcs );

                if( isempty( allCellInfo ) )
                    disp( [ 'Query ' mcs 'returned zero results ... continuing. (Did you forget to MatchMassAndVolume?)' ] );
                    continue
                end
     
            end 
            this.PlotAThing( "Density Summary", "Density Histogram", Queries, { "BuoyantDensity" }, "Histogram", [], 1, { 'pg/fl' } );
            this.PlotAThing( "Density Summary", "Buoyant Mass vs Volume", Queries, { "CalibratedWeightedVolume", "MatchedMass" }, "YX Marker", "Show Outliers",...
                [ this.PixelVolume 1], { 'fl', 'pg' } )
            % this.PlotAThing( "Density Summary", "Mass vs Volume", Queries, { "Volume", "MatchedMass" }, "YX Marker BadOnes" )
            % this.PlotAThing( "Density Summary", "Buoyant Mass vs Volume", Queries, { "Volume", "MatchedMass" }, 'Best Fit', [], ...
            %     [1 1], { 'fl', 'pg' } )

            % plot individual buoyant mass vs volume plots
            this.GetAxesHandle( "Individual Buoyant Mass vs Volume Plots", strcat( "Buoyant Mass vs Volume", Queries{1} ), "horizontal" );
            for ii = 1:numel( Queries )
                this.PlotAThing( "Individual Buoyant Mass vs Volume Plots", strcat( "Buoyant Mass vs Volume", Queries{ii} ), { Queries{ii} }, { "Volume", "MatchedMass" }, "YX Marker", [],...
                [1 1], { 'fl', 'pg' } )
            end

            this.PlotAThing( "Buoyant Density vs Mass", "Buoyant Density vs Mass", Queries, { "MatchedMass", "BuoyantDensity" }, "YX Marker", [],...
                [1 1], { 'pg', 'pg/fl' } )

            this.GetAxesHandle( "Mass Volume Summary", "Mass Violin Plot", "horizontal" );
            this.PlotAThing ( "Mass Volume Summary", "Mass Violin Plot", Queries, { "MatchedMass" }, 'Violin Plot', [], 1, { 'pg' } )
            this.PlotAThing ( "Mass Volume Summary", "Volume Violin Plot", Queries, { "Volume" }, 'Violin Plot', [], 1, { 'fl' } )
            this.PlotAThing ( "Mass Volume Summary", "Buoyant Density Violin Plot", Queries, { "BuoyantDensity" }, 'Violin Plot', [], 1, { 'pg/fl' } )
 
            this.PlotAThing( "Data vs Time", "Buoyant Mass vs Time", Queries, { "VolumeTime", "MatchedMass" }, 'YX Marker' )
            this.PlotAThing( "Data vs Time", "Volume vs Time", Queries, { "VolumeTime", "Volume" }, 'YX Marker' )
            this.PlotAThing( "Data vs Time", "Buoyant Density vs Time", Queries, { "VolumeTime", "BuoyantDensity" }, 'YX Marker' )
            %this.PlotAThing( "Data vs Time", "Buoyant Mass vs Time", Queries, { "VolumeTime", "MatchedMass" },  'Best Fit' )
            %this.PlotAThing( "Data vs Time", "Volume vs Time", Queries, { "VolumeTime", "Volume" }, 'Best Fit' )
            %this.PlotAThing( "Data vs Time", "Buoyant Density vs Time", Queries, { "VolumeTime", "BuoyantDensity" }, 'Best Fit' )
            this.PlotAThing ( "Buoyant Density", "Buoyant Density Violin Plot", Queries, { "BuoyantDensity" }, 'Violin Plot', [], 1, { 'pg/fl' } )
            this.PlotAThing( "Buoyant Density vs Mass", "Buoyant Density vs Buoyant Mass", Queries, { "MatchedMass", "BuoyantDensity" }, "YX Marker", [], [ 1 1], { 'pg', 'pg/fl' } )
        end

        function PlotAThing( this, FigureName, PlotName, Queries, Fields, PlotType, Options, UnitConversionFactors, UnitLabels )
            %TODO: fix UnitConversionFactors HACK
            if( nargin < 7 )
                Options = [];
            end

            if( nargin < 8 )
                UnitConversionFactors = ones( size( Fields ) );
            end

            if( nargin < 9 )
                UnitLabels = cell( 1, 2 );
            end

            lineColors = colororder;
            legendItems = gobjects( numel( Queries ), 1 );
            legendStrings = Queries;

            for ii = 1:numel( Queries )
                ah = this.GetAxesHandle( FigureName, PlotName );

                if( isempty( Queries ))
                    mcs = [];
                else
                    mcs = Queries{ii};
                end

                theCellInfo = this.SelectCellsFromResults( mcs );

                % extract data from specified fields
                goodData = cell( 1, numel( Fields ) );
                badData = cell( 1, numel( Fields ) );

                for jj = 1:numel( Fields )
                    % if( ~isfield( Fields{jj} ) )
                    %     continue
                    % end
                    goodData{jj} = [ theCellInfo.(Fields{jj}) ] * UnitConversionFactors(jj);
                end
    
                % remove outliers unless 'Keep Outliers' option specified
                if( ~strcmpi( Options, 'Keep Outliers' ) )
                    angle = cart2pol( [ theCellInfo.CalibratedWeightedVolume ], [ theCellInfo.MatchedMass ] );
                    badOnes = isoutlier( angle ) | isnan( [ theCellInfo.BuoyantDensity ] ) | isempty( [ theCellInfo.BuoyantDensity ] );
                    % [ linearModel, goodIndexes ] = fitPolynomialRANSAC( ...
                    %     [ theCellInfo.CalibratedWeightedVolume ], [ theCellInfo.MatchedMass ], 1, 15 );
                    for jj = 1:numel( Fields )
                        temp = goodData{jj};
                        badData{jj} = temp(badOnes);
                        goodData{jj} = temp(~badOnes);
                    end
                end

                axisLabels = Fields;
                xTickLabels = [];
                titleString = PlotName;

                switch( PlotType )
                    case 'YX Marker'
                        if( numel( Fields) == 1)
                            yData = goodData{1};
                            xData = 1:numel( yData );        
                        else
                            yData = goodData{2};
                            xData = goodData{1};    
                        end
        
                        legendItems(ii) = plot( ah, xData, yData, 'x', Color=lineColors(ii,:));
                        hold( ah, "on" )

                        % plot outliers if 'Show Outliers' option specified
                        if( strcmpi( Options, 'Show Outliers') )
                            if( numel( Fields) == 1 )
                                yData =badData{1};
                                xData = 1:numel( yData );        
                            else
                                yData = badData{2};
                                xData = badData{1};    
                            end
                            plot( ah, xData, yData, 'x', Color=[ 1 0 0 ] );
                        end

                    case 'Best Fit'
                        if( numel( Fields) == 1)
                            yData = goodData{1};
                            xData = 1:numel( yData );        
                        else
                            yData = goodData{2};
                            xData = goodData{1};    
                        end
        
                        bestFit = fitlm( xData, yData );
                        minMaxX = minmax( xData );
%                        minMaxX(1) = 0;
                        minMaxPredict = [ bestFit.predict( minMaxX(1) ), bestFit.predict( minMaxX(2) ) ];
                        legendItems(ii) = plot( ah, minMaxX, minMaxPredict, LineWidth=3, Color=lineColors(ii,:) );
                        slopeSignificantFigures = ceil( log10( bestFit.Coefficients{"x1","Estimate"} / bestFit.Coefficients{"x1","SE"} ) );
                        interceptSignificantFigures = ceil( log10( bestFit.Coefficients{"(Intercept)","Estimate"} / bestFit.Coefficients{"(Intercept)","SE"} ) );
                        slopeSignificanceLevel = bestFit.Coefficients{"x1","Estimate"} / bestFit.Coefficients{"x1","SE"};
                        slopeSignificanceLevel = min( 2, slopeSignificanceLevel );
                        slopeSignificanceMarker = "";
                        for jj = 1:floor( slopeSignificanceLevel )
                            slopeSignificanceMarker = slopeSignificanceMarker + "*";
                        end
                        interceptSignificanceLevel = bestFit.Coefficients{"(Intercept)","Estimate"} / bestFit.Coefficients{"(Intercept)","SE"};
                        interceptSignificanceLevel = min( 2, interceptSignificanceLevel );
                        interceptSignificanceMarker = "";
                        for jj = 1:floor( interceptSignificanceLevel )
                            interceptSignificanceMarker = interceptSignificanceMarker + "*";
                        end

                        legendStrings(ii) = ...
                            Queries(ii) + ...
                            " (" + slopeSignificanceMarker + "m=" + this.ConvertToEngineeringFormat( bestFit.Coefficients{"x1","Estimate"}, slopeSignificantFigures ) + ...
                            "±" + this.ConvertToEngineeringFormat( bestFit.Coefficients{"x1","SE"}, 2 ) + " s.e. " + ...
                            ", " + interceptSignificanceMarker + "b=" + this.ConvertToEngineeringFormat( bestFit.Coefficients{"(Intercept)","Estimate"}, interceptSignificantFigures ) + ...
                            "±" + this.ConvertToEngineeringFormat( bestFit.Coefficients{"(Intercept)","SE"}, 2 ) + " s.e. " + ...
                            ")"; 
                        hold( ah, "on" )

                    case 'Histogram'
                        dataToPlot = goodData{1};
                        [ counts, bins ] = histcounts( dataToPlot, 21 );
                        xAxis = ( bins(2:end) + bins(1:(end-1)) ) / 2;
                        plot( ah, xAxis, counts);
                        ah.XLim = [ 0, 1.05 * max( bins )];
                        legendStrings(ii) = ...
                            Queries(ii) + ... "N = " num2str( numel( theData ) ) + ...
                            ", µ_{\frac{1}{2}=" + num2str( median( dataToPlot ), '%0.2g' ) + ...
                            ", µ=" + num2str( mean( dataToPlot ), '%0.2g' ) + ...
                            ", σ=" + num2str( std( dataToPlot ), '%0.2g' ) + " s.e.)"; 
                        hold( ah, 'on' )    

                    case 'Violin Plot'
                        dataToPlot = goodData{1};
                        swarmchart( ah, ii * ones( size( dataToPlot ) ), dataToPlot, [], lineColors(ii,:) )
                        hold( ah, 'on' );
                        theMedian = median( dataToPlot, "omitnan" );
                        theMean = mean( dataToPlot, "omitnan" );
                        plot( ah, ii + [ -.25 .25 ], [ theMedian theMedian ], 'color', [ 0 0 0 ], 'LineWidth', 5 );
                        labelText = {   [ '\textrm{' Queries{ii} '}' ]; ...
                            [ 'N=' num2str( numel( dataToPlot ) )]; ...
                            [ '\mu=' num2str( theMean, '%0.2g' ) ]; ...                    
                            [ '\mu_{\frac{1}{2}}=' num2str( theMedian, '%0.2g' ) ]; ...                    
                            [ '\textrm{CV}=' num2str( std( dataToPlot )/abs( mean( dataToPlot) ) * 100, '%0.2g' ) ] };
                        labelText = cellfun( @(s) [ s '\\' ], labelText, UniformOutput=false );
                        labelText = [ labelText{:} ];
                        if( ii == 1 )
                            ah.XTick = 1:numel(Queries);
                        end
                        ah.TickLabelInterpreter = 'latex';
                        ah.XTickLabel{ii} = [ '$$\begin{array}{c}', labelText, '\end{array}$$' ];
                        ah.XAxis.FontSize = 12;

                        % text( ah, ii -.5, 0.95 * max( dataToPlot ), ...
                        %     {   Queries{ii}, ...
                        %         [ 'N=' num2str( numel( dataToPlot ) )], ...
                        %         [ '$$\mu=' num2str( theMean, '%0.2g' ) '$$' ], ...                    
                        %         [ '$$\mu_{\frac{1}{2}}=' num2str( theMedian, '%0.2g' ) '$$' ], ...                    
                        %         [ '$$CV=' num2str( std( dataToPlot )/abs( mean( dataToPlot) ) * 100, '%0.2g' ), '\%$$'] }, ...
                        %     FontSize=14, Interpreter='latex' , FontWeight='bold', VerticalAlignment='middle' );
                        ah.XLim = [ 0, ii + 1 ];
                        ah.YLim = [ 0, max( ah.YLim(2), 1.05 * max( dataToPlot ) ) ];
                end
            end

            % plot legend if present
            validLegendItems = isgraphics( legendItems );
            if( any( validLegendItems ) )
                legend( legendItems(validLegendItems), legendStrings{validLegendItems}, FontSize=16, Location='northwest' );
            end

            if( ~isempty( titleString ))
                title( ah, titleString, FontSize=16 )
            end

            if( isscalar( axisLabels ) )
                ylabel( ah, [ convertStringsToChars( axisLabels{1} ) ' (' UnitLabels{1} ')' ], FontSize=18 );
            end

            if( length( axisLabels ) == 2 )
                xlabel( ah, [ convertStringsToChars( axisLabels{1} ) ' (' UnitLabels{1} ')' ], FontSize=18 );
                ylabel( ah, [ convertStringsToChars( axisLabels{2} ) ' (' UnitLabels{2} ')' ], FontSize=18 );
            end
        end    
    end

    % image processing functions
    % TODO: parameterize this
    methods ( Static )
        function [BrightfieldImageData, FluorescentImageData, ReferenceImageData] = ReadImageDataFromHdf5FileStatic( Hdf5FilePath, hdf5PathsBF, hdf5PathsFL )        
            % initialize cell arrays to store frames
            BrightfieldImageData = cell(1, numel(hdf5PathsBF));
            FluorescentImageData = cell(1, numel(hdf5PathsFL));
            ReferenceImageData = cell(1, numel(hdf5PathsFL));
            
            % read the frames and store them in the cell array
            for jj = 1:numel(hdf5PathsBF)
                BrightfieldImageData{jj} = h5read(Hdf5FilePath, hdf5PathsBF{jj})';
                thisFrame = h5read(Hdf5FilePath, hdf5PathsFL{jj})';
                % Separate fluorescent image and reference image for each frame
                middleRow = size(thisFrame, 1) / 2;
                FluorescentImageData{jj} = thisFrame(1:middleRow, :, :);
                ReferenceImageData{jj} = thisFrame(middleRow+1:end, :, :);
            end
        end

        function [FullFrameBrightfieldImageData, ...
                  FullFrameFluorescentImageData, ...
                  FullFrameReferenceImageData] = ...
                  ReadFullFrameDataFromHdf5FileStatic(FullFrameHdf5FilePath, hdf5PathsFull)
            % ReadFullFrameDataFromHdf5FileStatic reads the full-frame Brightfield, 
            % Fluorescence, and Reference images from the specified HDF5 file.        
            % Initialize cell arrays to store the full-frame images
            nPaths = numel(hdf5PathsFull);
            FullFrameBrightfieldImageData = cell(1, nPaths);
            FullFrameFluorescentImageData = cell(1, nPaths);
            FullFrameReferenceImageData   = cell(1, nPaths);
        
            % Loop through each "folder" (group) path
            for jj = 1:nPaths
                currentPath = hdf5PathsFull{jj};
                % Get info on all datasets under this path
                try
                    info = h5info(FullFrameHdf5FilePath, currentPath);
                catch Error
                    disp(Error.message)
                    FullFrameBrightfieldImageData = [];
                    return
                end
                % Loop through each dataset in this folder
                for iDataset = 1:numel(info.Datasets)
                    datasetName = info.Datasets(iDataset).Name;
                    % Construct the full path to the dataset
                    datasetFullPath = [currentPath '/' datasetName];
                    % Read the dataset
                    thisFrame = h5read(FullFrameHdf5FilePath, datasetFullPath)';
                    % Identify Brightfield or Fluorescent+Reference
                    if startsWith(datasetName, 'BR_')
                        % Store as brightfield image
                        FullFrameBrightfieldImageData{jj} = thisFrame;
                    elseif startsWith(datasetName, 'FL_')
                        % Separate the stacked fluorescent/reference image
                        middleRow = size(thisFrame, 1) / 2;
                        FullFrameFluorescentImageData{jj} = thisFrame(1:middleRow, :, :);
                        FullFrameReferenceImageData{jj}   = thisFrame(middleRow+1:end, :, :);
                    end
                end
            end
        end


        function showATransitStatic(Hdf5FilePath, cellInfo, BRFrameSize, FLFrameSize, hdf5PathsBF, hdf5PathsFL, AxesHandle)
            if nargin < 6
                AxesHandle = [];
            end
        
            % Read image data from HDF5 file
            [BrightfieldImageData, FluorescentImageData, ReferenceImageData] = VolumeExclusionAnalysis.ReadImageDataFromHdf5FileStatic(Hdf5FilePath, hdf5PathsBF, hdf5PathsFL);
        
            % Initialize full frame placeholders
            fullFrameBF = 128 * ones(BRFrameSize, 'uint8'); % Mid-gray for brightfield
            fullFrameFL = 128 * ones(FLFrameSize, 'uint16'); % Mid-gray for fluorescent
            fullFrameRef = 128 * ones(FLFrameSize, 'uint16'); % Mid-gray for reference
        
            numFrames = numel(BrightfieldImageData);
        
            % Loop over all frames and place the cropped images in the composite image
            for jj = 1:numFrames
                % Get size and position for brightfield image
                BFSize = cellInfo.ImageSizeBF(jj, :);
                if any(BFSize > fliplr(size(fullFrameBF)))
                    continue
                end
                BFPos = mod(cellInfo.ImagePositionBF(jj, :), fliplr(size(fullFrameBF)));
        
                % Get size and position for fluorescent image
                FLSize = cellInfo.ImageSizeFL(jj, :);
                if any(FLSize > fliplr(size(fullFrameFL)))
                    continue
                end
                FLPos = cellInfo.ImagePositionFL(jj, :);
        
                % Ensure the cropped image fits within the full frame
                if BFPos(1) < 1 || BFPos(2) < 1 || ...
                        BFPos(1) + BFSize(1) - 1 > size(fullFrameBF, 2) || ...
                        BFPos(2) + BFSize(2) - 1 > size(fullFrameBF, 1)
                    warning('Brightfield cropped image exceeds the boundaries of the full frame. Cropping to fit.');
                    
                    % Adjust Brightfield Position and Size
                    BFPos(1) = max(1, BFPos(1));
                    BFPos(2) = max(1, BFPos(2));
                    
                    BFSize(1) = min(BFSize(1), size(fullFrameBF, 2) - BFPos(1) + 1);
                    BFSize(2) = min(BFSize(2), size(fullFrameBF, 1) - BFPos(2) + 1);
                end
            
                if FLPos(1) < 1 || FLPos(2) < 1 || ...
                        FLPos(1) + FLSize(1) - 1 > size(fullFrameFL, 2) || ...
                        FLPos(2) + FLSize(2) - 1 > size(fullFrameFL, 1)
                    warning('Fluorescent cropped image exceeds the boundaries of the full frame. Cropping to fit.');
                    
                    % Adjust Fluorescent Position and Size
                    FLPos(1) = max(1, FLPos(1));
                    FLPos(2) = max(1, FLPos(2));
                    
                    FLSize(1) = min(FLSize(1), size(fullFrameFL, 2) - FLPos(1) + 1);
                    FLSize(2) = min(FLSize(2), size(fullFrameFL, 1) - FLPos(2) + 1);
                end
        
                % Place the cropped images onto the full frames
                fullFrameBF(BFPos(2):BFPos(2) + BFSize(2) - 1, ...
                    BFPos(1):BFPos(1) + BFSize(1) - 1) = BrightfieldImageData{jj}(1:BFSize(2), 1:BFSize(1));
                fullFrameFL(FLPos(2):FLPos(2) + FLSize(2) - 1, ...
                    FLPos(1):FLPos(1) + FLSize(1) - 1) = FluorescentImageData{jj}(1:FLSize(2), 1:FLSize(1));
                fullFrameRef(FLPos(2):FLPos(2) + FLSize(2) - 1, ...
                    FLPos(1):FLPos(1) + FLSize(1) - 1) = ReferenceImageData{jj}(1:FLSize(2), 1:FLSize(1));
            end
        
            % Scale the brightfield image to match the 12-bit range
            fullFrameBF = uint16(fullFrameBF) * 16;
        
            % Resize images to match the largest image size
            maxWidth = max([size(fullFrameBF, 2), size(fullFrameFL, 2), size(fullFrameRef, 2)]);
            maxHeight = max([size(fullFrameBF, 1), size(fullFrameFL, 1), size(fullFrameRef, 1)]);
        
            resizedBF = imresize(fullFrameBF, [maxHeight, maxWidth]);
            resizedFL = imresize(fullFrameFL, [maxHeight, maxWidth]);
            resizedRef = imresize(fullFrameRef, [maxHeight, maxWidth]);
        
            % Create a buffer zone between images
            bufferZone = 2; % Buffer zone in pixels
            totalHeight = 3 * maxHeight + 2 * bufferZone;
            stackedImage = 128 * ones(totalHeight, maxWidth, 'uint16');
        
            % Stack images vertically with buffer zones
            stackedImage(1:maxHeight, :) = resizedBF;
            stackedImage(maxHeight + bufferZone + 1:2 * maxHeight + bufferZone, :) = resizedFL;
            stackedImage(2 * maxHeight + 2 * bufferZone + 1:end, :) = resizedRef;
            
            % Display the stacked image
            if isempty(AxesHandle)
                figure;
                imshow(stackedImage, []);
                title(['Transit Number ' num2str(RowNumber) ' - ' num2str(numFrames) ' frames']);
            else
                imshow(stackedImage, [], 'Parent', AxesHandle);
            end
        end

        function analysisObject = quickLoadObject()
            % Prompt the user to select a .mat file
            [fileName, filePath] = uigetfile('*.mat', 'Select the V.7.3 .mat file to load');
            fullPath = fullfile(filePath, fileName);
            
            if isequal(fileName, 0)
                disp('User canceled file selection.');
                analysisObject = [];
                return;
            end
            
            % Verify if the selected file is in v7.3 HDF5 format
            if ~H5F.is_hdf5(fullPath)
                disp('Selected file is not a valid HDF5-based v7.3 .mat file.');
                analysisObject = [];
                return;
            end
            
            % Use matfile to load only the 'this' variable
            try
                matObj = matfile(fullPath, 'Writable', false);  % Open the file as read-only
                analysisObject = matObj.this;  % Access the 'this' variable
                disp('Object loaded successfully.');
            catch ME
                disp(['Error loading object: ', ME.message]);
                analysisObject = [];
            end
        end


        function FilteredData = MatchedFilter( ImageData, objectType, objectSize)
            
            if nargin<2
                objectType = 'OnCell';
            end
            if nargin<3
                objectSize = 2.5;
            end

            persistent templateType templateSize template;
            if isempty(templateType)
                templateType = objectType;
            end
            if isempty(templateSize)
                templateSize = objectSize;
            end

            if (~strcmp(templateType, objectType) || isempty(template) || objectSize ~= templateSize)
                templateSize = objectSize;
                switch(templateType)
                    case 'Gaussian2DBlur' 
                        template = VolumeExclusionAnalysis.DrawGaussian2DBlur ( [ 21, 21 ], 1, [ 21, 21 ] / 2, templateSize , templateSize, 0 );
                    case 'GassuianCapsule'
                        template = VolumeExclusionAnalysis.DrawGaussianCapsule ( [ 21, 21 ], 1, [ 21, 21 ] / 2, templateSize, templateSize, 0 );
                    case 'Capsule'
                        template = VolumeExclusionAnalysis.DrawCapsule ( [ 21, 21 ], 1, [ 21, 21 ] / 2, templateSize, templateSize, 0 );
                    case 'Streak'
                        template = VolumeExclusionAnalysis.DrawStreak ( [ 21, 21 ], 1, [ 21, 21 ] / 2, templateSize/2, templateSize, 2*templateSize );
                    case 'OnCell'
                        template = VolumeExclusionAnalysis.DrawOnCell ( [ 21, 21 ], 1, [ 21, 21 ] / 2, templateSize, templateSize, 0 );
                end
                template = template / sum( template(:) );
            end
            FilteredData = convn( ImageData, template, 'same' );
        end

        function Mask = CantileverMask( ImageData )
            [ clusterIndex, clusterMeans ] = kmeans( ImageData(:), 2 );
            [ ~, activeCluster ] = max( clusterMeans );
            Mask = reshape( clusterIndex == activeCluster, size( ImageData ) );
            for ii = 1:size(Mask, 3)
                Mask(:,:,ii) = imdilate( Mask(:,:,ii), strel( "disk", 3 ) );
            end
        end

        function MaskedData = MaskPixelsOutsideCantilever( ImageData )
            MaskedData = nan( size( ImageData ) );
            numberOfFrames = size( ImageData, 3 );
            for ii = 1:numberOfFrames
                thisFrame = ImageData(:,:,ii);
                [ clusterIndex, clusterMeans ] = kmeans( thisFrame(:), 2 );
                [ ~, activeCluster ] = max( clusterMeans );
                activePixelMask = reshape( clusterIndex == activeCluster, size( thisFrame ) );
                thisFrame(~activePixelMask) = nan;
                MaskedData(:,:,ii) = thisFrame;
            end
        end

        function ParameterVectorToVariables( ParameterValues, ParameterNames )
            for ii = 1:numel( ParameterNames )
                assignin("caller", ParameterNames{ii}, ParameterValues(ii) )
            end
        end

        function ClippedData = ClipBoxesFromMovie( MovieData, BoxSize, BoxCenter )
                boxHalfSize = ceil( BoxSize / 2 );
                boxBounds = round( [ BoxCenter(:,1) - boxHalfSize(1), BoxCenter(:,2) - boxHalfSize(2), BoxCenter(:,1) + boxHalfSize(1), BoxCenter(:,2) + boxHalfSize(2) ] );
                boxBounds( boxBounds(:,1) < 1, : ) = nan;
                boxBounds( boxBounds(:,3) > size( MovieData, 2), : ) = nan;
                boxBounds( boxBounds(:,2) < 1, : ) = nan;
                boxBounds( boxBounds(:,4) > size( MovieData, 1), : ) = nan;
                
                numberOfFrames = size( MovieData, 3 );
                ClippedData = nan( 2 * boxHalfSize(2)+1, 2*boxHalfSize(1)+1, numberOfFrames );
                for ii = 1:numberOfFrames
                    if( ~isnan( sum( boxBounds(ii,:))))
                        ClippedData(:,:,ii) = MovieData(boxBounds(ii,2):boxBounds(ii,4),boxBounds(ii,1):boxBounds(ii,3), ii);
                    end
                end
        end

        function NumberAsCharArray = ConvertToEngineeringFormat( Value, SignificantFigures )
            if Value == 0
                % Handle the special case where the number is 0
                fprintf(['0.', repmat('0', 1, SignificantFigures-1), 'E+000\n']);
                return;
            end
        
            % Adjust the number to have an exponent that is a multiple of 3
            exponent = floor(log10(abs(Value)));
            baseValue = Value / 10^exponent;
            
            % Calculate the number of digits before the decimal point
            digitsBeforeDecimal = floor(log10(abs(baseValue))) + 1;
            
            % Determine the number of digits after the decimal point
            decimalPlaces = max(SignificantFigures - digitsBeforeDecimal, 0);
            
            if( exponent == 0)
                NumberAsCharArray = convertCharsToStrings( num2str( Value, SignificantFigures ) );
                return
            end

            % Create the format string for the specified number of significant figures
            formatString = sprintf('%%.%dfx10^{%%+03d}', decimalPlaces);
            
            % Display the number in engineering format
            NumberAsCharArray = convertCharsToStrings( sprintf(formatString, baseValue, exponent) );        
        end        
        
        function ImageData = SimulatedCellDifferenceImage( NumberOfFrames, ImageSize, Parameters, LinearOutput )
            if( nargin < 4 )
                LinearOutput = false;
            end
            % Amplitude, Position, Radius, Velocity, ImagingDutyCycle
            VolumeExclusionAnalysis.ParameterVectorToVariables( Parameters, ...
                { 'InitialPositionX', 'InitialPositionY', 'VelocityX', 'VelocityY', 'Amplitude', 'Width', 'Height', 'ImageOffset', 'Distance' } );

            PositionXY = [ InitialPositionX, InitialPositionY ] + cumsum( [ 0, 0; repmat( [ VelocityX, VelocityY ], NumberOfFrames - 1, 1 ) ] );
            DifferenceImageOffset = Distance * [ VelocityX, VelocityY ];
            Angle = atand( VelocityY / VelocityX );
            ImageData = nan( ImageSize(1), ImageSize(2) * NumberOfFrames );
            for ii = 1:NumberOfFrames
                ImageData(:,(ImageSize(2)*(ii-1)+1):(ImageSize(2)*ii)) = ...
                    VolumeExclusionAnalysis.DrawGaussian2DBlur( ImageSize(1:2), Amplitude, PositionXY(ii,:), Width, Height, Angle ) - ...
                    VolumeExclusionAnalysis.DrawGaussian2DBlur( ImageSize(1:2), Amplitude, PositionXY(ii,:) - DifferenceImageOffset, Width, Height, Angle );
            end
            ImageData = ImageData + ImageOffset;
            if( LinearOutput )
                ImageData = ImageData(:);
            end
        end

        function ImageData = DrawGaussian2DBlur( ImageSizeYX, Amplitude, PositionXY, Width, Height, Angle )
            % make a grid with origin at the center of the streak
            [x, y] = meshgrid((1:ImageSizeYX(2)) - PositionXY(1), (1:ImageSizeYX(1)) - PositionXY(2) );

            % rotate coordinate system according to velocity vector
            unitVectorXY = [ cosd( Angle ), sind( Angle ) ];
            x = ( x * unitVectorXY(1) - y * unitVectorXY(2) ) / Width * 2;
            y = ( x * unitVectorXY(2) + y * unitVectorXY(1) ) / Height * 2;

            ImageData = Amplitude * exp( -(x.*y).^2 );
        end

        function ImageData = DrawGaussianCapsule( ImageSizeYX, Amplitude, PositionXY, Width, Height, Angle )
            % make a grid with origin at the center of the streak
            [x, y] = meshgrid((1:ImageSizeYX(2)) - PositionXY(1), (1:ImageSizeYX(1)) - PositionXY(2) );

            % rotate coordinate system according to velocity vector
            unitVectorXY = [ cosd( Angle ), sind( Angle ) ];
            x = ( x * unitVectorXY(1) - y * unitVectorXY(2) );
            y = ( x * unitVectorXY(2) + y * unitVectorXY(1) );

            middlePixels = abs( x )<Width/2;
            endPixels = ( abs(x) >= Width/2 );
            distanceFromCenters = hypot( abs(x)-Width/2, y ) / Height*4;

            ImageData = nan( ImageSizeYX );
            ImageData(middlePixels) = Amplitude * exp( -( y(middlePixels) / (Height/4) ).^2 );
            ImageData(endPixels) = Amplitude * exp( -distanceFromCenters(endPixels).^2 );
        end

        function ImageData = DrawCapsule( ImageSizeYX, Amplitude, PositionXY, Width, Height, Angle )
            % make a grid with origin at the center of the streak
            [x, y] = meshgrid((1:ImageSizeYX(2)) - PositionXY(1), (1:ImageSizeYX(1)) - PositionXY(2) );

            % rotate coordinate system according to velocity vector
            unitVectorXY = [ cosd( Angle ), sind( Angle ) ];
            x = ( x * unitVectorXY(1) - y * unitVectorXY(2) );
            y = ( x * unitVectorXY(2) + y * unitVectorXY(1) );

            ImageData = zeros( ImageSizeYX );
            ImageData(abs( x )<Width/2 & abs( y )<Height/2) = Amplitude * cos( pi/Height * y(abs( x )<Width/2 & abs(y)<Height/2) );
            distanceFromCenters = hypot( abs(x)-Width/2, y ) / Height*2;
            circlePixels = ( distanceFromCenters <=1 & abs(x) >= Width/2 );
            ImageData(circlePixels) = Amplitude * cos( pi/2*distanceFromCenters(circlePixels) );
        end

        function ImageData = DrawStreak( ImageSizeYX, Amplitude, PositionXY, Radius, VelocityXY, StreakLength )
            % make a grid with origin at the center of the streak
            [xDistance, yDistance] = meshgrid((1:ImageSizeYX(2)) - PositionXY(1), (1:ImageSizeYX(1)) - PositionXY(2) );

            % rotate coordinate system according to velocity vector
            unitVectorXY = [ VelocityXY(1), VelocityXY(2) ] / hypot( VelocityXY(1), VelocityXY(2) );
            xDistance = abs( xDistance * unitVectorXY(1) - yDistance * unitVectorXY(2) );
            yDistance = abs( xDistance * unitVectorXY(2) + yDistance * unitVectorXY(1) );
            
            % blank image
            ImageData = zeros( ImageSizeYX );

            % Compute the X profile
            ImageData(xDistance <= StreakLength / 2 & yDistance <= Radius) = 1;
            bounds = xDistance >= StreakLength/2 &  xDistance <= StreakLength/2 + Radius & yDistance <= Radius;
            ImageData(bounds) = cos( pi/2/Radius * ( xDistance(bounds) - StreakLength / 2) );
            
            % multiply by the Y profile
            ImageData(yDistance <= Radius) = ImageData(yDistance <= Radius) .* cos( pi/2/Radius * yDistance(yDistance <= Radius) );
            
            ImageData = Amplitude * ImageData;
        end
        
        function ImageData = DrawOnCell( ImageSize, Amplitude, Position, SigmaX, SigmaY, ThetaDegrees )
            [ x, y ] = meshgrid( 1:ImageSize(2), 1:ImageSize(1) );
            x = x - Position(1);
            y = y - Position(2);
            xPrime = x * cosd( ThetaDegrees ) - y * sind( ThetaDegrees );
            yPrime = x * sind( ThetaDegrees ) + y * cosd( ThetaDegrees );
            ImageData = Amplitude * exp( -( xPrime / SigmaX ).^2 ) .* exp( -( yPrime / SigmaY ).^2 );
        end

        % Helper function to merge PDFs using an external tool (pdftk or Ghostscript)
        function success = mergePDFs(pdfFiles, outputPdf)
            % Create the command to merge PDFs
            % Wrap each PDF path in double quotes
            quotedFiles = cellfun(@(x) ['"', x, '"'], pdfFiles, 'UniformOutput', false);

            % Join the quoted file paths into a single string
            pdfList = strjoin(quotedFiles, ' ');
            % Windows: Use pdftk
            command = sprintf('"C:\\Program Files (x86)\\PDFtk\\bin\\pdftk" %s cat output "%s"', pdfList, outputPdf);
        
            % Execute the command
            [status, cmdout] = system(command);
        
            if status == 0
                success = true;
            else
                success = false;
                disp(['PDF merge failed: ', cmdout]);
            end
        end
    end
end