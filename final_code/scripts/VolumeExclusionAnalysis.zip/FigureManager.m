classdef FigureManager < handle
    properties
        figureDictionary
    end

    methods
        function AxesHandle = GetAxesHandle( this, FigureName, PlotName, Arrangement )
            if( nargin < 4 )
                Arrangement = "flow";
            end

            if( isempty( this.figureDictionary ) )
                this.figureDictionary = dictionary;
                newFigure = true;
            else
                newFigure = ~this.figureDictionary.isKey( FigureName );
                if( ~newFigure )
                    newFigure = newFigure | ~isgraphics( this.figureDictionary( FigureName ).FigureHandle );
                end
            end

            if( newFigure )
                fh = figure( 'Name', FigureName, 'NumberTitle', 'off' );
                set(0,'units','pixels')  
                screenSize = get(0,'screensize');
                fh.Position = screenSize;
                lh = tiledlayout( fh, Arrangement ,"TileSpacing","Compact");
                this.figureDictionary(FigureName) = struct( ...
                    'FigureHandle', fh, ...
                    'LayoutHandle', lh, ...
                    'AxesDictionary', dictionary() );
                newAxes = true;
            else
                lh = this.figureDictionary(FigureName).LayoutHandle;
                newAxes = ~this.figureDictionary(FigureName).AxesDictionary.isKey( PlotName );
            end

            if( newAxes )
                AxesHandle = nexttile( lh );
                this.figureDictionary(FigureName).AxesDictionary(PlotName) = AxesHandle;
            else
                AxesHandle = this.figureDictionary(FigureName).AxesDictionary(PlotName);
            end
        end

        function SetFigureTitle( this, FigureName, FigureTitle )
            this.figureDictionary(FigureName).FigureHandle.Name = FigureTitle;
        end          

        function CloseFigure( this, FigureNamesToCloseCellArray )
            if( isempty( this.figureDictionary ) )
                return
            end

            if( nargin < 2 )
                FigureNamesToCloseCellArray = this.figureDictionary.keys;
            end

            for ii = 1:numel( FigureNamesToCloseCellArray )
                if( ~this.figureDictionary.isKey( FigureNamesToCloseCellArray{ii} ))
                    continue
                end

                fh = this.figureDictionary(FigureNamesToCloseCellArray{ii}).FigureHandle;

                if( isvalid( fh ) )
                    close( fh );
                    this.figureDictionary.remove( FigureNamesToCloseCellArray{ii} );
                    delete( fh );
                end
            end
        end

        function medians = ViolinPlotWithMedian( this, FigureName, Data, Fields, OmitOutliers )
            if( nargin < 5 )
                OmitOutliers = true;
            end

            medians = nan( numel( Fields ), numel( Data ) );
            for ii = 1:numel( Fields )
                ah = this.GetAxesHandle( FigureName, Fields(ii) );
                for jj = 1:numel( Data )
                    if( OmitOutliers )
                        outliers = isoutlier( Data(jj).(Fields{ii}), "grubbs" );
                        dataToPlot = Data(jj).(Fields{ii})(~outliers);
                    else
                        dataToPlot = Data(jj).(Fields{ii});
                    end
                    dataToPlot(isnan(dataToPlot)) = [];
                    if( isempty( dataToPlot ) )
                        continue
                    end
                    swarmchart( ah, jj * ones( size( dataToPlot ) ),  dataToPlot )
                    hold( ah, 'on' );
                    medians(ii, jj) = median( dataToPlot, "omitnan" );
                    plot( ah, jj + [ -.25 .25 ], [ medians(ii,jj), medians(ii,jj) ], 'color', [ 0 0 0 ], 'LineWidth', 5 )
                    text( ah, jj -.25, max( 0.9 * dataToPlot ), ...
                        {   [ 'N=' num2str( numel( dataToPlot ) )], ...
                            [ '$$\mu_{\frac{1}{2}}=' num2str( medians(ii, jj), 3 ) '$$' ], ...                    
                            [ '$$CV=' num2str( std( dataToPlot )/abs( mean( dataToPlot) ) * 100, 2), '\%$$']}, ...
                        'FontSize', 14, 'Interpreter', 'Latex' )
                end
                ah.XTick = 1:numel( Data );
                titleString = [ Fields{ii} ' (CV=' num2str( std( medians(ii,:), "omitnan" )/abs( mean( medians(ii,:), "omitnan" ) ) * 100, 2 ) '%'];
                if( OmitOutliers )
                    titleString = [ titleString ', Outliers Omitted'];
                end
                titleString = [ titleString ')' ];
                title( ah, titleString, "FontSize", 18)
                xlabel( ah, 'Sample Number')
            end
        end              
    end

    methods (Static)
        function TiledImage = TileImages( ImageMatrix )
            % Get the number of images and the size of each image
            [imageHeight, imageWidth, numImages] = size(ImageMatrix);
            
            % Best effort to achieve 4:3 aspect ratio for the tiled image
            desiredAspect = 4/3;
            bestDiff = inf;
            bestLayout = [1, numImages];
            
            for numRows = 1:numImages
                numCols = ceil(numImages / numRows);
                if numCols * numRows >= numImages % only valid layouts
                    aspectRatio = (numCols * imageWidth) / (numRows * imageHeight);
                    diff = abs(aspectRatio - desiredAspect);
                    if diff < bestDiff
                        bestDiff = diff;
                        bestLayout = [numRows, numCols];
                    end
                end
            end
            
            % Determine the size of the output image based on the best layout
            numRows = bestLayout(1);
            numCols = bestLayout(2);
            tiledHeight = numRows * imageHeight;
            tiledWidth = numCols * imageWidth;
            
            % Initialize the tiled image with zeros
            TiledImage = zeros(tiledHeight, tiledWidth);
            
            % Loop over each image and copy it into the correct position
            for i = 1:numImages
                row = floor((i - 1) / numCols) + 1;
                col = mod(i - 1, numCols) + 1;
                
                rowIndices = (row - 1) * imageHeight + (1:imageHeight);
                colIndices = (col - 1) * imageWidth + (1:imageWidth);
                
                TiledImage(rowIndices, colIndices) = ImageMatrix(:, :, i);
            end
        end  
    end
end
