%% AUTOMATIC RUN
clear all
% Create an instance of the class
analysis = VolumeExclusionAnalysis();
% Execute the main method
analysis.main();
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% MANUAL RUN
% Initialize analysis
clear all
analysis = VolumeExclusionAnalysis();
analysis.Hdf5FilePath = 'C:\Users\travera\Travera Dropbox\Selim Olcum\Travera Fluorescence Project\2024_07_29_1123_PC9\LC05_202407291049_Images_CROPPED.hdf5';
analysis.MassDataFilePath = 'C:\Users\travera\Travera Dropbox\Selim Olcum\Travera Fluorescence Project\2024_07_29_1123_PC9\2024_07_29_1123_PC9_MassData.csv';  % If you have mass data to analyze
[analysis.AnalysisFolderPath, analysis.SampleName] = fileparts(analysis.Hdf5FilePath);
analysis.Debug = true; 
%% Analysis Routine
analysis.LoadMetadata(true);
analysis.EliminateBadTransits(true);
analysis.MeasureVolume(true);
analysis.CleanTransitData(true);
analysis.CalibratePosition(true);
analysis.MatchMassAndVolume(true); 
%% Save Results
analysis.ExportScalarData(fullfile(analysis.AnalysisFolderPath, [analysis.SampleName, ' CellInfo.csv']));
analysis.ExportHdf5Index(fullfile(analysis.AnalysisFolderPath, [analysis.SampleName, ' Hdf5PathIndex.csv']))
save(fullfile(analysis.AnalysisFolderPath, [analysis.SampleName, ' Object-2.mat']), 'analysis', '-v7.3');
%% Plot Summary results
analysis.SummarizeErrors()
analysis.PlotSummary()
